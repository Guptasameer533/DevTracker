# DevTrack — Technical Architecture & High-Level Design

**Document version:** 1.0
**Author:** Sameer Gupta (Engineering)
**Status:** Design review
**Companion to:** DevTrack PRD v2.0
**Last updated:** April 2026

---

## P0 Architecture Summary — Build This First

*An engineer implementing the MVP should build only what's listed in this section. Sections §0–§18 below describe the v2.0 target state. Consult them as reference for Phase 2+; do not implement them yet. Scope drift is the #1 risk to shipping on time.*

**MVP in one sentence:** A single logged-in user connects one GitHub repo and sees a chart of their last 30 days of commits.

### P0 — Tables (Prisma schema)

Only four models exist in v1.0:

```
User          id, githubId (u), username (u), email, avatarUrl,
              accessToken (encrypted at rest), createdAt, updatedAt

Session       id, token (u), userId → User, expiresAt, createdAt

Repository    id, userId → User, githubRepoId (u), name, fullName,
              private (bool), archived (bool), createdAt

Commit        id, repoId → Repository, sha, message, authorLogin,
              timestamp, url
              @@unique(repoId, sha)
```

One user owns at most one repo (per PRD FR-REPO-3). `Repository.userId` becomes `Repository.teamId` in P1 via the expand-contract migration in §16.1.

### P0 — Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/v1/health` | Liveness probe; returns 200 only if DB reachable |
| GET | `/api/v1/auth/github` | Issue state cookie, redirect to GitHub OAuth |
| GET | `/api/v1/auth/github/callback` | Verify state, exchange code, create session |
| GET | `/api/v1/auth/me` | Current user + connected repo metadata (if any) |
| POST | `/api/v1/auth/logout` | Delete session row, clear cookie |
| GET | `/api/v1/repos/available` | List user's GitHub repos (Postgres-cached 5 min) |
| POST | `/api/v1/repos` | Connect one repo — body: `{ githubRepoId }` |
| GET | `/api/v1/stats/commits?from&to` | Daily commit buckets for the connected repo |

**Not in P0:** any team endpoint, any webhook endpoint, any PR or issue endpoint, any refresh-token endpoint.

### P0 — Auth

- GitHub OAuth 2.0 **authorization code flow** with `state` in a 10-minute signed cookie (CSRF protection)
- Requested scopes: `read:user`, `user:email`, `repo`
- Session: random 32-byte token persisted in `sessions` table, 7-day TTL
- Session cookie: `HttpOnly`, `Secure`, `SameSite=Lax`
- **No JWT, no refresh tokens, no rotation** — all deferred to P1 (§6.2 / ADR-003)
- GitHub `accessToken` encrypted at rest with AES-256-GCM using `ENCRYPTION_KEY` (§6.5); key must be validated as exactly 32 bytes at startup

### P0 — Explicitly out of scope (do not build)

Teams, invitations, roles · Webhooks, HMAC verification · Per-developer breakdown · PRs and issues (commits only) · JWT access/refresh tokens · Individual vs team views · Repo disconnection UI (disconnect is DB/API-only in v1.0)

### P0 — Dependencies

- **Backend:** `express`, `@prisma/client`, `prisma`, `axios`, `zod`, `helmet`, `cors`, `morgan`, `cookie-parser`, `express-rate-limit`, `winston`, `dotenv`
- **Frontend:** `react`, `react-dom`, `react-router-dom`, `@tanstack/react-query`, `axios`, `recharts`, `tailwindcss`, `vite`
- **Dev:** `nodemon`, `jest`, `supertest`, `cross-env` (Windows/macOS parity — stated project requirement)

### P0 — Environment variables

Required: `DATABASE_URL`, `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`, `SESSION_SECRET`, `ENCRYPTION_KEY`, `FRONTEND_URL`, `PORT`, `NODE_ENV`. All validated with Zod at startup; process exits if any are missing or malformed.

P1 will add: `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`, `WEBHOOK_SECRET`, `POSTHOG_API_KEY`.

### P0 — Ship gate

All four must hold before calling v1.0 done:
1. A user can complete the GitHub OAuth flow and land on `/dashboard`
2. A user can pick one of their GitHub repos and connect it
3. The dashboard renders a Recharts chart with real commit data for the last 30 days
4. Backend is live on Render, frontend is live on Vercel, both accessible at public URLs; `/health` returns 200

### Which sections of the full HLD apply to P0?

| Use these for P0 | Skip for P0 — P1 or later |
|------------------|---------------------------|
| §2 (C4 diagrams — adapted mentally: no teams) | §4.1 ERD — teams/PR/issue/webhook rows |
| §3 (layering rules — controllers/services/data) | §6.2 (JWT) — P1 via ADR-003 |
| §5 (API conventions — envelope, versioning) | §6.3 (RBAC) — no roles in P0; user owns repo |
| §6.1 (OAuth flow), §6.4 (secrets), §6.5 (token encryption) | §7 (webhook ingestion) — P1 entirely |
| §8 (stats — simplify to one-user, one-repo case) | §9.1 — collapse team-scoped threats |
| §10 (observability — logs + requestId) | §16.1, §16.2 (migrations) — execute when P1 starts |
| §11 ADRs 001, 002, 005, 006, 007, 008 | §11 ADR-003 (JWT), ADR-004 (webhooks) — P1 |
| §12 (deployment), §14 (reliability), §15 (testing) | §17 TQ-01, TQ-07 — webhook-specific |
| §17 TQ-02, TQ-03, TQ-04, TQ-05 | |

---

## 0. Document Purpose & Audience

This document specifies the technical design of DevTrack. It complements — does not duplicate — the PRD. The PRD answers *what* we are building and *why*; this document answers *how*.

**Audience:** Engineers writing or reviewing the DevTrack codebase. Assumes familiarity with HTTP, REST, SQL, OAuth 2.0, JWT, and web application architecture.

**What this document is:**
- The source of truth for architectural decisions
- A reference for onboarding new contributors
- A design-review artifact before implementation

**What this document is not:**
- A line-by-line code specification (that's the code itself)
- A project schedule (see PRD §20)
- A business case (see PRD §1–3)

---

## 1. Context & Constraints

### 1.1 Non-functional drivers

The design is shaped by three hard constraints that override otherwise reasonable choices:

| Constraint | Implication |
|-----------|-------------|
| **Free-tier hosting only** (Vercel + Render) | No Redis, no message queue, no Kafka. Single-process backend. Cold starts acceptable. |
| **Solo contributor, part-time** | Operational burden must be near-zero. No pager. No custom infrastructure. Use managed services aggressively. |
| **Portfolio artifact, not a business** | Code quality and demonstrability matter more than throughput or uptime. A readable `stats.service.js` is worth more than a 10% perf win. |

### 1.2 Scale assumptions

These numbers drive capacity planning throughout the document. They are deliberately modest — we design for demo scale, not hypothetical millions.

| Metric | v1.0 target | v2.0 target |
|--------|-------------|-------------|
| Concurrent users | 5 | 50 |
| Registered users | 100 | 1,000 |
| Connected repos total | 100 | 3,000 |
| Commits stored | 10,000 | 500,000 |
| Webhook events/day | 0 (no webhooks in v1.0) | 10,000 |
| Peak requests/minute | 50 | 500 |

### 1.3 Non-goals (technical)

- No multi-region deployment
- No horizontal scaling of the backend (single instance)
- No eventual-consistency patterns (synchronous writes only)
- No microservices (monolith, period)
- No GraphQL (REST is sufficient for this scale and simpler to demo)
- No TypeScript in v1.0 (plain JS with JSDoc; TS migration can be a P2 line item)

---

## 2. System Architecture — C4 Model

### 2.1 Level 1 — System Context

```
                        ┌──────────────────────┐
                        │                      │
                        │     GitHub.com       │
                        │  (OAuth, API, hooks) │
                        │                      │
                        └──────┬──────┬────────┘
                               │      │
                    OAuth/REST │      │ webhook POST (P1)
                               ▼      │
    ┌─────────────┐     ┌──────────────────┐     ┌──────────────┐
    │             │     │                  │     │              │
    │   User      │────▶│    DevTrack      │────▶│   PostHog    │
    │ (browser)   │◀────│    System        │     │ (analytics)  │
    │             │     │                  │     │              │
    └─────────────┘     └──────────────────┘     └──────────────┘
```

**Actors:**
- **User** — authenticated humans interacting via the browser
- **GitHub** — upstream system for auth and data (bidirectional: we call their API, they call our webhook)
- **PostHog** — write-only destination for product analytics

### 2.2 Level 2 — Containers

```
DevTrack System
┌────────────────────────────────────────────────────────────────────────┐
│                                                                        │
│  ┌─────────────────────┐            ┌───────────────────────────┐      │
│  │                     │            │                           │      │
│  │  Web Client (SPA)   │            │    API Server             │      │
│  │  React + Vite       │───HTTPS───▶│    Node.js + Express      │      │
│  │                     │◀───JSON────│                           │      │
│  │  Runs in browser    │            │    Single process         │      │
│  │  Hosted on Vercel   │            │    Hosted on Render       │      │
│  └─────────────────────┘            └────────┬──────────────────┘      │
│                                              │                         │
│                                              │ SQL (TLS)               │
│                                              ▼                         │
│                                   ┌───────────────────────────┐        │
│                                   │                           │        │
│                                   │   PostgreSQL              │        │
│                                   │   Render managed          │        │
│                                   │                           │        │
│                                   └───────────────────────────┘        │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

**Container responsibilities:**

| Container | Responsibilities | Does not do |
|-----------|-----------------|-------------|
| Web Client | Render UI, manage client-side routing, call API, display charts | Store secrets, compute aggregates, talk directly to GitHub |
| API Server | Authenticate requests, proxy GitHub, compute aggregates, enforce authz, verify webhooks | Serve static assets, handle long-running jobs (no jobs yet) |
| PostgreSQL | Persist all state of record | Contain logic (no triggers, no stored procs) |

**Note on the monolith choice:** At this scale, separating webhook ingestion from the API into its own service (a common pattern) is premature. The webhook workload is bursty but low-volume, and Express handles it fine in the same process. When webhook load exceeds ~100/min sustained, we'd extract it to a worker. That threshold is 10x our v2.0 target, so it's a v3 problem.

### 2.3 Level 3 — API Server internals

```
┌──────────────────────────────────────────────────────────────────────┐
│                    API Server (Express, single process)             │
│                                                                      │
│   ┌──────────────────┐  request flow top→bottom                      │
│   │ Middleware stack │                                               │
│   │  1. helmet       │  ← security headers                           │
│   │  2. cors         │  ← origin check                               │
│   │  3. rawBody      │  ← webhooks only (for HMAC)                   │
│   │  4. express.json │                                               │
│   │  5. requestId    │  ← trace ID injection                         │
│   │  6. morgan       │  ← access log                                 │
│   │  7. rateLimiter  │                                               │
│   └────────┬─────────┘                                               │
│            ▼                                                         │
│   ┌──────────────────┐                                               │
│   │     Routers      │  Route dispatch by prefix                     │
│   │  /auth  /repos   │                                               │
│   │  /stats /teams   │                                               │
│   │  /webhooks       │                                               │
│   └────────┬─────────┘                                               │
│            ▼                                                         │
│   ┌──────────────────┐                                               │
│   │ Route middleware │  authenticate, requireTeamAccess              │
│   └────────┬─────────┘                                               │
│            ▼                                                         │
│   ┌──────────────────┐                                               │
│   │   Controllers    │  Parse input, call service, shape response    │
│   └────────┬─────────┘                                               │
│            ▼                                                         │
│   ┌──────────────────┐     ┌──────────────────────────┐              │
│   │    Services      │────▶│  GitHub Service (HTTP)   │              │
│   │  (business logic)│     └──────────────────────────┘              │
│   └────────┬─────────┘                                               │
│            ▼                                                         │
│   ┌──────────────────┐                                               │
│   │   Prisma Client  │  Typed DB queries                             │
│   └────────┬─────────┘                                               │
│            ▼                                                         │
│   ┌──────────────────┐                                               │
│   │  Error Handler   │  ← all uncaught errors land here              │
│   │  (final mw)      │                                               │
│   └──────────────────┘                                               │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

The layering (**controller → service → data**) is enforced by code organization, not by a framework. Controllers may not import Prisma directly. Services may not import Express `req`/`res`. This makes services unit-testable without HTTP.

---

## 3. Component Breakdown

### 3.1 Web Client

**Responsibilities**
- Handle routing, auth state, data fetching, rendering.
- Maintain a single source of truth for auth (session context).
- Never compute aggregates — trust the API.

**Module boundaries:**
- `src/pages/` — route-level components. No business logic.
- `src/components/` — reusable UI. Stateless where possible.
- `src/context/AuthContext` — single provider for user identity.
- `src/services/api.js` — Axios instance with interceptors. Only place in the app that knows the API base URL.
- `src/hooks/` — domain hooks wrapping TanStack Query (`useStats`, `useRepos`).

**Why this structure:** if we ever split into a mobile app, everything under `services/` and `hooks/` is reusable. Pages and components are platform-specific.

### 3.2 API Server

Organized into four layers:

**Middleware** — cross-cutting concerns (security, logging, rate limiting, body parsing). Order matters and is documented inline in `app.js`.

**Routers** — thin files that declare paths and wire middleware. No logic.

**Controllers** — handle HTTP specifics: parse `req`, validate with Zod, call a service, format response via `response.js` helpers. Controllers are thin; they should rarely exceed 20 lines per handler.

**Services** — business logic. A service is a plain module of functions; it does not know about Express. `github.service.js` is the only service allowed to make outbound HTTP calls. `stats.service.js` is the only service allowed to aggregate data.

### 3.3 Data layer

PostgreSQL accessed through Prisma. All queries are typed. No raw SQL except where justified (aggregation queries on commits may use `$queryRaw` for performance; must be code-reviewed).

Migrations are Prisma migrations committed to the repo. `prisma migrate deploy` runs on every backend deploy before the server starts.

---

## 4. Data Architecture

### 4.1 Full ERD (v2.0)

```
┌──────────────┐         ┌──────────────────┐        ┌──────────────┐
│    User      │─────────│  TeamMember      │────────│    Team      │
│              │ 1    n  │                  │ n    1 │              │
│ id           │         │ id               │        │ id           │
│ githubId  U  │         │ teamId           │        │ name         │
│ username  U  │         │ userId           │        │ ownerId      │
│ email        │         │ role (enum)      │        │ createdAt    │
│ avatarUrl    │         │ joinedAt         │        └──────┬───────┘
│ accessTokn E │         │ @@unique(t,u)    │               │
│ createdAt    │         └──────────────────┘               │ 1
│ updatedAt    │                                            │
└──────┬───────┘                                            │ n
       │                                                    ▼
       │                                           ┌──────────────────┐
       │ 1                                         │  Repository      │
       │                                           │                  │
       │                                           │ id               │
       │ n                                         │ teamId           │
┌──────▼──────────┐                                │ githubRepoId U   │
│ RefreshToken    │                                │ name             │
│                 │                                │ fullName         │
│ id              │                                │ private (bool)   │
│ token         U │                                │ webhookId (int?) │
│ userId          │                                │ archived (bool)  │
│ expiresAt       │                                │ createdAt        │
│ createdAt       │                                └────┬────┬────┬───┘
└─────────────────┘                                     │    │    │
                                                        │ 1  │ 1  │ 1
                                                        │    │    │
                                         ┌──────────────┘    │    └──────────────┐
                                         │ n               n │                 n │
                                         ▼                   ▼                   ▼
                                 ┌───────────────┐  ┌─────────────────┐  ┌──────────────┐
                                 │   Commit      │  │  PullRequest    │  │    Issue     │
                                 │               │  │                 │  │              │
                                 │ id            │  │ id              │  │ id           │
                                 │ repoId        │  │ repoId          │  │ repoId       │
                                 │ sha           │  │ githubPrId      │  │ ghIssueId    │
                                 │ message       │  │ title           │  │ title        │
                                 │ authorLogin   │  │ state (enum)    │  │ state (enum) │
                                 │ authorId (?)  │  │ authorLogin     │  │ authorLogin  │
                                 │ timestamp     │  │ createdAt       │  │ createdAt    │
                                 │ url           │  │ mergedAt        │  │ closedAt     │
                                 │ @@u(repo,sha) │  │ closedAt        │  │ @@u(repo,id) │
                                 └───────────────┘  │ @@u(repo,prId)  │  └──────────────┘
                                                    └─────────────────┘

                                 ┌──────────────────┐
                                 │ WebhookEvent     │
                                 │                  │
                                 │ id               │
                                 │ repoId           │
                                 │ eventType        │
                                 │ githubDlvrId  U  │ ← dedup key
                                 │ processed (bool) │
                                 │ createdAt        │
                                 └──────────────────┘
```

Legend: **U** = unique, **E** = encrypted at rest, **?** = nullable.

### 4.2 Why this schema

**Two principles drove the design:**

1. **GitHub is the system of record; we are a cache.** Every row in `commits`, `pull_requests`, `issues` is sourced from GitHub and uniquely identified by a GitHub identifier (`sha`, `githubPrId`, `githubIssueId`). We can always rebuild our DB by re-querying GitHub, so we do not need to be paranoid about write durability beyond the basics.

2. **Users are nullable on commits because commits have authors who are not DevTrack users.** An external contributor who pushes to a connected repo appears in stats by their GitHub login, even though they never signed up. `authorId` is nullable; `authorLogin` is required.

### 4.3 Indexes and access patterns

Every query the app makes at runtime is enumerated below. Each has either an existing index or a justification for a full scan.

| Query | Where it's called | Index used |
|-------|-------------------|-----------|
| Get user by sessionId / refresh token | Auth middleware, every request | `sessions(token)` / `refresh_tokens(token)` |
| Get user by githubId | OAuth callback | `users(githubId)` — unique |
| Get team membership for (teamId, userId) | Team authz check | `team_members(teamId, userId)` — composite unique |
| List commits for repo in date range | `getTeamStats` | `commits(repoId, timestamp DESC)` |
| Group commits by authorLogin in date range | `getDeveloperBreakdown` | Same index; grouping is in-memory |
| Look up webhook event by deliveryId | Webhook dedup | `webhook_events(githubDeliveryId)` — unique |
| Find repo by githubRepoId | Connect repo — prevents duplicate | `repositories(githubRepoId)` — unique |

Queries that intentionally full-scan small tables: listing teams for a user, listing repos for a team. These tables stay in the hundreds even at v2.0 scale and don't warrant additional indexes.

### 4.4 Caching strategy

**We run no Redis.** Caching is done in-process (in-memory) or in Postgres, depending on data.

| Data | Cache | TTL | Reason |
|------|-------|-----|--------|
| GitHub API responses (repo list, commits) | Postgres table `github_cache` | 5 min | Avoid re-hitting rate-limited API on every page load |
| User session → user object | In-memory LRU, 1000 entries | 60 sec | Reduces auth middleware DB hits by ~95% in practice |
| Team membership check result | In-memory LRU, 500 entries | 60 sec | Hot path on every team-scoped request |

**Why Postgres for GitHub cache, not in-memory:** survives restarts, shared across future worker instances if we scale out. A 5-minute TTL on a commits-for-repo query is fine since dashboards update via webhook, not cache expiry.

**Invalidation:** in-memory caches are fire-and-forget TTL; we accept up to 60 sec of staleness on authz changes. Postgres GitHub cache is invalidated eagerly when a webhook event arrives for that repo (write commits to DB + clear cache entry in same transaction).

---

## 5. API Design

### 5.1 Conventions

- All routes: `/api/v1/<resource>`
- Case: kebab-case for URLs, camelCase for JSON bodies
- HTTP verbs used strictly (GET idempotent, POST creates, PATCH updates, DELETE removes)
- Pluralize resources (`/repos`, not `/repo`)
- Nested only where hierarchy is truly 1:N and never navigated from the child (`/teams/:teamId/members` OK; would not do `/users/:userId/commits`)

### 5.2 Response envelope

Success:
```json
{
  "success": true,
  "data": { ... },
  "meta": { "page": 1, "total": 42 }   // only on paginated responses
}
```

Error:
```json
{
  "success": false,
  "message": "Human-readable error message",
  "code": "REPO_NOT_FOUND",
  "requestId": "req_abc123",
  "errors": { "fieldName": ["specific validation error"] }  // only for 400s
}
```

`requestId` is attached to every response; logs are keyed on it. If a user reports a bug, they can provide the requestId and we can find all related log lines.

### 5.3 Pagination

Cursor-based, not offset-based. Endpoints that return lists accept:

- `cursor` — opaque token from previous response
- `limit` — max 100, default 25

Response includes `meta.nextCursor` (null if no more). We use cursor because:
- Offset pagination is inconsistent under concurrent writes
- Cursor scales past 10k rows without performance degradation
- Recruiter-visible: shows up in every list endpoint

### 5.4 Versioning

`/api/v1/...` today. When a breaking change is required, `/api/v2/...` is added alongside v1. v1 remains available until all clients migrate (or until the project is abandoned).

Non-breaking changes (adding a field, adding an endpoint) are made on v1 without bumping. We follow the rule: if removing the change would break clients, it's breaking; otherwise it's additive.

### 5.5 Idempotency

POSTs that create resources accept an optional `Idempotency-Key` header. If the same key is seen twice within 24h, the second request returns the first response. Not required in v1.0 but designed in.

---

## 6. Authentication & Authorization

### 6.1 OAuth 2.0 — authorization code flow

We use the **authorization code flow** (not implicit, not client credentials). PKCE is not required because we have a confidential client (our backend holds the secret), but we still implement the `state` parameter to prevent CSRF on the redirect.

```
┌─────────┐         ┌──────────┐          ┌──────────────┐         ┌────────────┐
│ Browser │         │ DevTrack │          │   GitHub     │         │ DevTrack   │
│         │         │ Frontend │          │              │         │ Backend    │
└────┬────┘         └─────┬────┘          └──────┬───────┘         └─────┬──────┘
     │  click "Sign in"   │                       │                      │
     ├───────────────────▶│                       │                      │
     │                    │ window.location =     │                      │
     │                    │ /api/v1/auth/github   │                      │
     │                    │───────────────────────┼─────────────────────▶│
     │                    │                       │                      │
     │                    │                       │   Generate state,   │
     │                    │                       │   store in cookie    │
     │                    │                       │                      │
     │                    │                  302 Redirect                │
     │◀───────────────────┼───────────────────────┼──────────────────────┤
     │                    │                       │                      │
     │   GET github.com/login/oauth/authorize     │                      │
     ├────────────────────┼──────────────────────▶│                      │
     │                    │                       │                      │
     │       consent screen                       │                      │
     │◀───────────────────┼───────────────────────┤                      │
     │                    │                       │                      │
     │   user clicks Approve                      │                      │
     ├────────────────────┼──────────────────────▶│                      │
     │                    │                       │                      │
     │                 302 redirect to callback?code=X&state=Y           │
     │◀───────────────────┼───────────────────────┤                      │
     │                    │                       │                      │
     │   GET /api/v1/auth/github/callback?code=X&state=Y                 │
     ├────────────────────┼───────────────────────┼─────────────────────▶│
     │                    │                       │                      │
     │                    │                       │  Verify state matches cookie
     │                    │                       │                      │
     │                    │                       │   Exchange code      │
     │                    │                       │◀─────────────────────┤
     │                    │                       │                      │
     │                    │                       │   access_token       │
     │                    │                       ├─────────────────────▶│
     │                    │                       │                      │
     │                    │                       │   GET /user          │
     │                    │                       │◀─────────────────────┤
     │                    │                       │                      │
     │                    │                       │   user profile       │
     │                    │                       ├─────────────────────▶│
     │                    │                       │                      │
     │                    │                       │  Upsert user, create │
     │                    │                       │  session, set cookie │
     │                    │                       │                      │
     │             302 redirect to /dashboard                            │
     │◀───────────────────┼───────────────────────┼──────────────────────┤
```

**Security controls in this flow:**

1. **`state` parameter** — generated random 32 bytes, stored in a short-lived (10 min) signed cookie. Verified on callback. Mitigates CSRF against the OAuth flow.
2. **`redirect_uri` exact match** — registered with GitHub OAuth App. GitHub refuses any callback to an unregistered URI.
3. **`code` is single-use and short-lived** (10 min) by GitHub design.
4. **`access_token` never seen by the browser** — exchanged server-side only.
5. **Session cookie: `HttpOnly`, `Secure`, `SameSite=Lax`** — protects against XSS-based token theft and most CSRF vectors.

### 6.2 Session (P0) vs JWT (P1)

**P0 uses signed session cookies.** A session cookie contains a session ID (random 32 bytes); the session record is stored in Postgres. Logout deletes the session row.

**P1 migrates to JWT access + refresh tokens.** Why the migration at all?

- Sessions require a DB lookup per request — fine at our scale, but JWT lets us scale the backend horizontally without sticky sessions.
- JWT is more interview-discussable. (Honest reason — see §11 ADR-003.)

**JWT design (P1):**

- Access token: 15 min TTL, signed with `JWT_ACCESS_SECRET` (HS256). Payload: `{ sub: userId, iat, exp }`.
- Refresh token: 7 days TTL, signed separately. Stored server-side in `refresh_tokens` table so we can revoke.
- **Rotation on every refresh:** using a refresh token invalidates it and issues a new pair. If an attacker uses a stolen refresh token, the legitimate user's next refresh will fail, signaling compromise.
- Frontend stores tokens in memory + httpOnly cookie for refresh token. Not localStorage — XSS-vulnerable.

### 6.3 Authorization (RBAC)

Two roles exist in the system and one implicit role:

- **OWNER** (explicit, per-team) — can invite/remove members, connect/disconnect repos, delete the team
- **MEMBER** (explicit, per-team) — can view dashboards, view team members, cannot modify anything
- **NONE** (implicit) — users with no team membership cannot see team data

Authorization is enforced at the route-middleware level via `requireTeamAccess(role?)`. Example:

```js
router.post('/teams/:teamId/members',
  authenticate,
  requireTeamAccess('OWNER'),
  teamController.inviteMember
);
```

No authorization logic lives in controllers or services. If it's not behind middleware, it's public — that makes security review straightforward.

### 6.4 Secret management

- Local dev: `.env` file, gitignored
- Production: Render environment variables, set via Render dashboard (never via code)
- Rotation: `WEBHOOK_SECRET` and `JWT_*_SECRET` can be rotated; old values must coexist for grace period (list of valid secrets, not single)
- GitHub `accessToken` stored per user in DB, encrypted at rest with AES-256-GCM using `ENCRYPTION_KEY` from env

### 6.5 Token encryption at rest

```
Plaintext GitHub token → AES-256-GCM(key=ENCRYPTION_KEY, iv=random 12B)
                       → stored as: iv || ciphertext || tag (all base64)
```

**Why encrypt even though the DB is itself behind auth:** defense in depth. A compromised backup, misconfigured role, or SQL injection doesn't immediately leak GitHub tokens. The key is in env vars, outside the DB.

**Key rotation:** not supported in v1.0. All tokens would need to be re-encrypted, which is a one-time migration. Accepted as debt.

---

## 7. Webhook Ingestion Pipeline (P1)

### 7.1 End-to-end sequence

```
                         GitHub                            DevTrack API
                           │                                     │
                    Commit pushed                                │
                           │                                     │
                    POST /api/v1/webhooks/github                 │
                    Headers:                                     │
                      X-Hub-Signature-256                        │
                      X-GitHub-Event                             │
                      X-GitHub-Delivery                          │
                    Body: <push payload>                         │
                           ├────────────────────────────────────▶│
                           │                                     │
                           │                         1. Capture raw body (before json parse)
                           │                         2. Verify HMAC(rawBody, WEBHOOK_SECRET)
                           │                            === header signature
                           │                                     │
                           │                         3. Check webhook_events by delivery ID
                           │                            INSERT, on conflict DO NOTHING
                           │                                     │
                           │                         4. If conflict (dup): log + return 200
                           │                            (idempotent, 9 of 10 replay attempts
                           │                             are silent)
                           │                                     │
                           │                         5. Dispatch on X-GitHub-Event:
                           │                              push         → upsert Commits
                           │                              pull_request → upsert PR
                           │                              issues       → upsert Issue
                           │                                     │
                           │                         6. Update webhook_events.processed = true
                           │                                     │
                           │                         7. Return 200 within 10s budget
                           │◀────────────────────────────────────┤
```

### 7.2 HMAC verification

```javascript
const sig = req.headers['x-hub-signature-256'];     // "sha256=abc..."
const computed = 'sha256=' +
  crypto.createHmac('sha256', WEBHOOK_SECRET)
        .update(req.rawBody)
        .digest('hex');

if (!timingSafeEqual(Buffer.from(sig), Buffer.from(computed))) {
  return res.status(401).send();
}
```

**Critical detail: `req.rawBody`** must be the exact bytes GitHub sent, before any JSON parsing. We capture it via:

```js
app.use('/api/v1/webhooks', express.raw({ type: 'application/json' }), (req, res, next) => {
  req.rawBody = req.body;  // Buffer
  req.body = JSON.parse(req.body.toString('utf8'));
  next();
});
```

Using `express.json()` *first* would mutate the body and break HMAC verification. This is a common bug we avoid by design.

**Timing-safe comparison** (`crypto.timingSafeEqual`) prevents a theoretical side-channel where an attacker observes response time to infer the correct signature byte-by-byte. At our scale, `===` would likely work, but doing it correctly is table-stakes.

### 7.3 Idempotency via `X-GitHub-Delivery`

GitHub sends a unique delivery ID in every webhook call. We use this as our dedup key.

```sql
INSERT INTO webhook_events (id, repoId, eventType, githubDeliveryId, processed)
VALUES (?, ?, ?, ?, false)
ON CONFLICT (githubDeliveryId) DO NOTHING;
```

If the insert did nothing (conflict), we skip processing and return 200. GitHub retries webhooks that fail (non-2xx or timeout); they will happily send the same delivery ID 5+ times. Our dedup makes this safe.

**Why not UPDATE instead of INSERT ... DO NOTHING?** Because deletion history matters. If the first attempt crashed mid-processing, we want a paper trail. A separate `processed` flag lets us distinguish "saw this, still processing" from "saw this, done."

### 7.4 Event handlers

Each event type has an idempotent handler. Idempotency is enforced by the unique constraints on data rows (`(repoId, sha)`, `(repoId, githubPrId)`, `(repoId, githubIssueId)`).

Example for push:
```js
async function handlePush(repoId, payload) {
  const commits = payload.commits.map(c => ({
    repoId,
    sha: c.id,
    message: c.message.slice(0, 1000),   // cap at 1k chars
    authorLogin: c.author.username || c.author.name,
    timestamp: new Date(c.timestamp),
    url: c.url,
  }));

  await prisma.commit.createMany({
    data: commits,
    skipDuplicates: true,                 // idempotent via unique(repoId, sha)
  });
}
```

If the same push is replayed, `skipDuplicates: true` + unique index → no-op. The operation is safe to run 100 times.

### 7.5 Failure modes

| Failure | Behavior |
|---------|----------|
| HMAC fails | 401, log at WARN with delivery ID and repo; do not reveal why |
| DB insert fails (transient) | 500; GitHub retries in 1 min, 5 min, 30 min, 1 hr, 6 hr |
| Payload parse error | 400; do not retry — data is unsalvageable |
| Handler throws | 500; retry path as above |
| Processing takes >10s | GitHub considers it failed; we still complete; retry will dedup |

**We explicitly do NOT queue webhooks to a worker in v2.0.** At 10,000 events/day (~7/min average), synchronous processing handles bursts fine. When we hit 100/min sustained, add a queue (Bull + Redis, or Render's native jobs).

---

## 8. Stats Aggregation Engine

### 8.1 Query pattern analysis

The hot query is **"total commits for team X in date range Y"**. Let's trace it.

```sql
-- Naive:
SELECT COUNT(*) FROM commits
WHERE "repoId" IN (SELECT id FROM repositories WHERE "teamId" = $1)
AND "timestamp" BETWEEN $2 AND $3;
```

At v2.0 scale: 3000 repos, 500k commits, typical team has 5 repos → subquery returns 5 rows, outer query scans the index `(repoId, timestamp)`. Estimated execution: < 10ms.

### 8.2 Budgets per endpoint

These are the latency budgets we design to. Every piece of work on a hot path has a budget; if a piece exceeds its budget we investigate.

| Endpoint | Total budget (p95) | DB work | GitHub API work | Cache work | App logic |
|----------|-------------------|---------|-----------------|------------|-----------|
| `GET /auth/me` | 100ms | 10ms (session lookup) | 0 | 60ms (cache hit) | 30ms |
| `GET /stats/commits` | 300ms | 50ms (3 aggregation queries) | 0 (served from cache) | 50ms | 200ms network/serialization |
| `POST /repos` | 2000ms | 20ms | 1500ms (create webhook + fetch metadata) | 0 | 480ms |
| `POST /webhooks/github` | 500ms | 40ms (dedup insert + commit inserts) | 0 | 0 | 460ms headroom |

The generous "app logic" numbers include JSON serialization, network, and framework overhead — not literal computation time. The budgets are realistic for Render's free-tier shared CPU.

### 8.3 Aggregation implementation

The developer breakdown query:

```js
const breakdown = await prisma.commit.groupBy({
  by: ['authorLogin'],
  where: { repoId: { in: repoIds }, timestamp: { gte: from, lte: to } },
  _count: { id: true },
  orderBy: { _count: { id: 'desc' } },
  take: 50,
});
```

Prisma compiles this to a `GROUP BY` with an ordered `COUNT(*)`. At our scale, this runs in milliseconds on the `(repoId, timestamp)` index.

We also need PR and issue counts per author. The natural instinct is to UNION the three tables. We don't — we do three separate queries and merge in Node. Reason:

- UNION across commits/pull_requests/issues would not use indexes well
- Three simple queries, each using its index, total ~30ms
- The merge in Node is O(n) over ~50 rows; trivial

This is the kind of trade-off (simple-fast-correct vs. clever-complex) where "boring" wins.

### 8.4 Timeline query

The activity timeline is a bucketed count by date:

```js
const commits = await prisma.commit.findMany({
  where: { repoId: { in: repoIds }, timestamp: { gte: from, lte: to } },
  select: { timestamp: true },
});

const buckets = {};
for (const { timestamp } of commits) {
  const date = timestamp.toISOString().slice(0, 10);
  buckets[date] = (buckets[date] || 0) + 1;
}
```

For 30 days of data, this fetches at most a few thousand rows and buckets in memory. It's fine. When we hit 100k commits per month per team, we'd move to:

```sql
SELECT date_trunc('day', timestamp) AS day, COUNT(*)
FROM commits
WHERE repoId IN (...) AND timestamp BETWEEN $1 AND $2
GROUP BY day ORDER BY day;
```

Deferred until actually needed.

---

## 9. Security Architecture

### 9.1 Threat model — STRIDE applied

| Category | Threat | Control |
|----------|--------|---------|
| **Spoofing** | Attacker forges webhook | HMAC-SHA256 with shared secret |
| **Spoofing** | Attacker impersonates user via stolen session | HttpOnly + Secure + SameSite cookie; short-lived sessions; IP change detection (P2) |
| **Spoofing** | Attacker impersonates DevTrack to GitHub | OAuth Client Secret never exposed client-side |
| **Tampering** | SQL injection | Prisma parameterizes all queries; no `$queryRaw` with user input |
| **Tampering** | XSS to exfiltrate tokens | Tokens are HttpOnly (never in JS); React escapes by default; CSP header set |
| **Repudiation** | User denies performing action | Action logs keyed on userId + requestId (audit trail) |
| **Info disclosure** | Error messages leak internals | Production errors return generic messages + requestId; details in logs only |
| **Info disclosure** | `.env` committed to git | Pre-commit hook + gitignore; CI check for secrets |
| **Info disclosure** | GitHub tokens in DB leaked in backup | Encrypted at rest with AES-256-GCM |
| **Info disclosure** | API returns data across tenants | Every team-scoped query filters on team membership at the middleware level |
| **DoS** | Brute-force auth | Rate limit (20/15min); OAuth itself is rate-limited by GitHub |
| **DoS** | Flood general endpoints | Rate limit (100/15min) |
| **DoS** | Large request bodies | `express.json({ limit: '100kb' })` |
| **Elevation of privilege** | MEMBER calls OWNER-only endpoint | `requireTeamAccess('OWNER')` middleware |

### 9.2 Security headers

Set via Helmet:

```js
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],   // Tailwind-generated
      imgSrc: ["'self'", "data:", "https://avatars.githubusercontent.com"],
      connectSrc: ["'self'", "https://api.github.com"],
    },
  },
  hsts: { maxAge: 31536000, includeSubDomains: true },
}));
```

### 9.3 Dependency security

- `npm audit` runs on every CI build; `high` or `critical` vulnerabilities fail the build
- Dependabot configured for weekly dep updates
- Lockfile (`package-lock.json`) committed; no `^` in versions we control

---

## 10. Observability

### 10.1 Logging

**What we log:**
- Every incoming request (method, path, status, duration, requestId, userId if auth'd)
- Every unhandled exception (full stack, requestId, contextual fields)
- Every external API call (URL, status, duration)
- Every auth decision (authenticate success/fail, authz denial)

**What we do NOT log:**
- Request bodies (may contain PII)
- GitHub access tokens (ever)
- Webhook payloads in full (only metadata: event type, delivery ID, repo)
- Query strings with potentially-sensitive params

**Format:** structured JSON in production, human-readable in development.

```json
{
  "level": "info",
  "time": "2026-04-19T...",
  "requestId": "req_abc123",
  "userId": "u_xyz",
  "method": "GET",
  "path": "/api/v1/stats/commits",
  "status": 200,
  "durationMs": 47,
  "msg": "request completed"
}
```

### 10.2 Metrics

At our scale, metrics are informal — derived from log aggregation on Render. If this were a real product, we'd add Prometheus exposition. For now, a weekly log review answers:

- What's p95 latency per endpoint?
- What's the error rate?
- Which endpoints are hottest?

### 10.3 Request tracing

Every request gets a `requestId` from middleware — UUIDv4 at the edge, propagated through logs. When a user reports a bug, they include the requestId and we can retrieve the full log trace.

External calls (GitHub API) log the parent requestId so we can trace "user did X → we called GitHub Y → GitHub responded Z."

### 10.4 Alerting

Not implemented in v2.0. If the backend is fully down, Render's built-in service health shows red; that's sufficient. A real product would alert on:

- p95 latency > 2s sustained for 5 min
- Error rate > 1% sustained for 5 min
- Webhook queue depth > 100 (when we have a queue)

---

## 11. Architecture Decision Records (ADRs)

Shortened ADRs capturing the key decisions. Each has Context → Decision → Consequences.

### ADR-001: Monolith over microservices

**Context:** Common reflex at Senior+ level is to split services. DevTrack has auth, webhook processing, stats — natural boundaries.

**Decision:** Single Node.js process. All logic in one codebase, deployed as one unit.

**Consequences:**
- (+) One deploy, one log stream, one DB, one set of env vars
- (+) No distributed tracing problem; no inter-service auth
- (+) Refactoring across modules is a local change
- (−) When webhook load becomes heavy, we'll need to extract. Budget: 1 week to do so when triggered.
- **Reversible:** yes, relatively cheaply.

### ADR-002: Postgres over MongoDB

**Context:** We have clearly relational data (users → teams → repos → commits).

**Decision:** PostgreSQL via Prisma.

**Consequences:**
- (+) Foreign keys, uniqueness, transactions without gymnastics
- (+) SQL is universally understood
- (+) Free tier available on Render
- (−) Schema migrations are a concern (managed via Prisma migrations)
- **Reversible:** no. Data migration from Postgres to Mongo would be nontrivial.

### ADR-003: Session cookies (P0) → JWT (P1)

**Context:** Either works. Sessions are simpler but require a DB lookup per request. JWTs are stateless but harder to revoke.

**Decision:** Session cookies for v1.0. Migrate to JWT + refresh rotation for v2.0.

**Consequences:**
- (+) P0 ships faster and simpler (cookie middleware + 1 table)
- (+) P1 demonstrates JWT rotation, a valuable interview topic
- (−) Migration path requires all users to re-login (acceptable; no data loss)
- **Reversible:** yes at any time.

### ADR-004: Synchronous webhook processing (no queue)

**Context:** The textbook answer to webhooks is "receive → enqueue → respond 200 → process async in worker." This adds Redis + a worker process.

**Decision:** Process synchronously. Return 200 after DB writes.

**Consequences:**
- (+) No Redis dependency; simpler ops
- (+) At 10/min peak, sync works comfortably within GitHub's 10s timeout
- (−) A slow DB query could tie up an Express worker
- (−) If we need to do expensive post-processing (e.g., fetch PR diff), we'll need a queue
- **Reversible:** yes; queue pattern is a known refactor.

### ADR-005: Prisma ORM over raw SQL or Knex

**Context:** Query-building options range from raw SQL (max flexibility, max work) to Prisma (typed, ergonomic, slightly magic).

**Decision:** Prisma.

**Consequences:**
- (+) Schema file is single source of truth
- (+) Migrations handled natively
- (+) Typed queries catch bugs at dev time
- (−) Aggregation queries occasionally require `$queryRaw`
- (−) ORM adds latency compared to raw SQL (negligible at our scale)
- **Reversible:** partially — schema migration is fine; query rewrites would be a big effort.

### ADR-006: REST over GraphQL

**Context:** GraphQL is common at scale.

**Decision:** REST.

**Consequences:**
- (+) No GraphQL infrastructure; curl-inspectable
- (+) Simpler caching (HTTP cache)
- (+) OpenAPI-generatable later
- (−) Over-fetching is possible; addressed by targeted endpoints
- **Reversible:** yes; GraphQL can coexist.

### ADR-007: Recharts over D3

**Context:** Chart libraries range from D3 (full power, steep curve) to Chart.js / Recharts (opinionated, ergonomic).

**Decision:** Recharts.

**Consequences:**
- (+) Declarative React API; matches the rest of the codebase
- (+) Readable in a PR review
- (−) Customization limited; if we need custom chart types, we'd fall back to D3 or Visx
- **Reversible:** yes at the component level.

### ADR-008: Vercel + Render (split hosting) over one-vendor

**Context:** Fly.io, Railway, Render all offer "everything on one vendor." Vercel is the best React host; Render is the best Node+Postgres host.

**Decision:** Vercel for frontend, Render for backend + DB.

**Consequences:**
- (+) Best-in-class per layer
- (+) Free tiers work for both
- (−) CORS configuration, two deploy pipelines
- (−) Two vendor dashboards to monitor
- **Reversible:** yes; both Vercel and Render can host the full stack with work.

---

## 12. Deployment Architecture

### 12.1 Environments

| Env | Purpose | Hosting | Data |
|-----|---------|---------|------|
| Dev | Local development | localhost:3000 + localhost:5173 | Local Postgres |
| Staging | Pre-prod verification | Render staging + Vercel preview branches | Staging Postgres |
| Prod | User-facing | Render prod + Vercel prod | Prod Postgres |

Staging is optional for a solo project. We deploy `main` → prod directly; PRs are reviewed against a Vercel preview URL for the frontend.

### 12.2 CI/CD pipeline

```
Developer pushes commit to feature branch
           │
           ▼
GitHub Actions: CI
  ├─ server: npm ci
  ├─ server: npm run lint
  ├─ server: npm test
  ├─ server: npx prisma validate
  ├─ client: npm ci
  ├─ client: npm run lint
  ├─ client: npm run build  (catches build errors)
  └─ npm audit (fails on high/critical)
           │
           ▼
PR opened → Vercel preview deploy (frontend only)
           │
           ▼
PR merged to main
           │
           ▼
GitHub Actions: Deploy
  ├─ Render autodeploys backend from main (runs migrate deploy + npm start)
  └─ Vercel autodeploys frontend from main
           │
           ▼
Post-deploy smoke test (GET /health returns 200 with DB check)
  └─ If fails, alert in GitHub Action output
```

### 12.3 Database migrations

Migrations are Prisma-generated SQL files committed to `server/prisma/migrations/`. On deploy, Render runs:

```
npx prisma migrate deploy
```

before starting the server. This ensures schema matches code before traffic arrives.

**Zero-downtime guarantees:**
- Additive changes (new column, new index) are always safe
- Destructive changes (drop column, change type) require a two-step migration: first the code stops using the column, then the next release drops it
- We have one backend instance → there's no "some instances have old code, some have new" window. Render does a rolling restart, but the single container means either-or.

### 12.4 Rollback

If a deploy breaks production:

1. Revert the commit on `main`
2. Push → Render autodeploys the revert
3. If the migration is destructive, write a compensating migration

Estimated rollback time: 5–10 min from detection to restored.

### 12.5 Backups

Render's free Postgres includes daily backups, retained 7 days. For a portfolio project this is fine. A real product would want:

- Point-in-time recovery
- Off-site backup copy
- Tested restore procedure quarterly

---

## 13. Scalability & Performance

### 13.1 Current capacity

Render free tier: 512 MB RAM, shared CPU. Node event loop can handle a few hundred concurrent connections on this hardware.

Postgres free tier: 256 MB RAM, 1 GB storage. Connection limit: 97. Prisma's default pool is 10 — plenty of headroom.

**Realistic peak we can handle on free tier:** ~50 concurrent users doing dashboard views, ~500 req/min. Matches v2.0 targets.

### 13.2 Scaling axes

When we outgrow free tier, the first bottlenecks and their fixes:

| Bottleneck | Fix | Cost |
|-----------|------|------|
| Node process CPU | Upgrade Render plan to dedicated CPU | $7/mo |
| Postgres storage | Upgrade to paid Postgres | $7/mo |
| Request volume → single instance | Add 2nd Render instance behind their LB | 2x infra |
| Webhook burst | Add Bull + Redis queue | +$7/mo for Redis |
| Read volume on commits | Add Postgres read replica | 2x DB cost |
| Global latency | CDN for frontend (already via Vercel); not an issue |

**Notable:** scaling the Node backend horizontally works only after we migrate to JWT (P1). With sessions, we'd need sticky sessions or move sessions to Redis.

### 13.3 Hot paths

The dashboard load is the hottest path. We optimize it specifically:

- Dashboard HTML: served by Vercel CDN, cached globally
- `/auth/me`: 60s in-memory cache → ~99% avoid DB
- `/stats/commits`: 5 min Postgres cache → ~95% avoid GitHub API
- Static assets: Vercel CDN

A warm user load hits the DB twice (auth + stats) and both queries run in < 20 ms total.

---

## 14. Reliability & Availability

### 14.1 Aspirational SLOs (informational, not enforced)

- Availability: 99% (allows ~7h of downtime/mo — realistic for free tier with cold starts)
- p95 latency, dashboard: 300 ms (warm); 30 s (cold start)
- p95 latency, webhook: 500 ms
- Data durability: 99.9% (Render Postgres daily backups)

### 14.2 Failure modes and degradation

| Failure | User-visible effect | System response |
|---------|--------------------|-----------------|
| Render cold start | 30s first request latency | Banner: "Waking up free-tier server" |
| GitHub API down | Dashboard shows stale cache | Banner: "GitHub seems unreachable; showing cached data" |
| GitHub API rate-limited | Connect-repo fails | 503 with retry-after, UI retries with backoff |
| Postgres connection lost | 503 on all endpoints | Render health check flaps → auto-restart |
| Backend crash | 503 until Render restarts (~30s) | Vercel shows friendly error page |
| Frontend JS bundle fails to load | Blank page | User refreshes; Vercel edge serves previous version |

### 14.3 Disaster recovery

| Scenario | Recovery strategy | RTO | RPO |
|----------|-------------------|-----|-----|
| Postgres corruption | Restore from Render daily backup | ~30 min | 24 hours |
| Accidental delete (dropped table) | Same as above | ~30 min | 24 hours |
| Both Vercel + Render down | Wait out the outage | Depends on vendors | 0 (no data loss) |
| Domain loss | Reclaim via registrar; update DNS | ~1 hour | 0 |

**RPO of 24 hours is only acceptable because:** GitHub is our source of truth. If we lose the DB, we re-run OAuth + backfill for active users and rebuild commit data. Data loss is recoverable from upstream — a unique property of this system.

---

## 15. Testing Strategy

### 15.1 Test pyramid

```
                        ▲
                       ╱ ╲      E2E (Playwright)
                      ╱   ╲     few — slowest
                     ╱─────╲
                    ╱       ╲   Integration (Jest + Supertest)
                   ╱         ╲  dozens — API contract tests
                  ╱───────────╲
                 ╱             ╲ Unit (Jest)
                ╱               ╲ many — fast, isolated
                ─────────────────
```

### 15.2 Specific tests

**Unit — targeted at services (no HTTP, no DB)**
- `stats.service.getTeamStats` with known fixtures
- `jwt.utils` round-trip (sign → verify)
- HMAC verification function with real GitHub payload fixtures
- Error types format correctly

**Integration — run against a test Postgres**
- Auth flow: login → me → logout
- Create team → invite member → verify membership
- Webhook POST with valid HMAC → commit row appears
- Webhook POST with invalid HMAC → 401, no row
- Webhook replay with same delivery ID → idempotent, one row
- Rate limit trips after N requests
- Authz: MEMBER forbidden from OWNER-only endpoint

**E2E — optional, Playwright**
- Visit landing → click "Demo" → chart renders
- Visit landing → click "Sign in with GitHub" → (mocked OAuth) → dashboard

### 15.3 Coverage targets

- Unit + integration on services: ≥ 70%
- Controllers: covered by integration tests; no explicit controller unit tests
- Middleware: unit tests for auth, webhook-verify, error-handler

### 15.4 CI gates

- Tests must pass
- ESLint must pass
- Build must succeed
- `npm audit` must have no `critical` vulns

---

## 16. Migration Plan: P0 → P1 → P2

### 16.1 P0 → P1 (adding teams)

The biggest migration. `repositories.userId` → `repositories.teamId`.

**Strategy: expand-contract.**

**Step 1 — Expand (deploy 1):**
- Add `teams`, `team_members` tables
- Add `repositories.teamId` nullable column
- Code reads from either `userId` (existing) or `teamId` (new); prefers new if present

**Step 2 — Backfill (one-off script):**
- For each existing user with repos: create a "Personal" team, set them as OWNER
- Update each of their repos to point to the new team
- Verify counts

**Step 3 — Contract (deploy 2):**
- Make `teamId` NOT NULL
- Drop `repositories.userId`
- Code only reads from `teamId`

Downtime: zero. Each deploy is compatible with the previous code version.

### 16.2 P0 → P1 (session cookie → JWT)

**Strategy: parallel authentication.**

**Step 1:** Deploy JWT code paths alongside session cookies. New logins issue JWTs; existing sessions continue to work.

**Step 2:** Sessions expire (7-day TTL). Over 7 days, all users migrate organically.

**Step 3:** Remove session cookie code.

Downtime: zero. Existing users never see an error; just continue using their session until it expires.

### 16.3 P2 considerations

- **Read replicas:** Prisma supports multiple clients pointing to primary vs replica. Add as a new `prisma.replica` client, migrate read-heavy queries (stats) to use it.
- **Redis + queue:** Add a new `queue.service.js`; webhook controller enqueues instead of processing. Minimal churn.
- **TypeScript:** Migrate file-by-file, starting with `utils/` (no dependencies). Maintain JS/TS interop via `.d.ts` stubs.

---

## 17. Open Technical Questions

| # | Question | Impact | Decision owner |
|---|----------|--------|----------------|
| TQ-01 | How do we handle force-pushes that rewrite commit history on webhook? | Data accuracy for stats | Me; default: keep original commits, do not reconcile |
| TQ-02 | Do we run Prisma migrations from CI or from the backend container on startup? | Deploy mechanics | Me; default: from container (Render start command) — simpler |
| TQ-03 | How do we handle GitHub rate limits during backfill for large repos (10k+ commits)? | Onboarding UX | Me; cap initial backfill at 30 days; scroll backward lazily on demand |
| TQ-04 | What's the strategy when a user rotates their GitHub personal access token externally? | Ongoing data fetch | Me; default: detect 401 on next API call, mark accessToken invalid, prompt re-auth |
| TQ-05 | Cursor pagination — base64(JSON) or opaque hash? | API design | Me; default: base64(JSON{id, createdAt}) — simpler to debug |
| TQ-06 | Do we need request tracing beyond requestId (e.g., OpenTelemetry)? | Observability | Me; default: no for v2.0, revisit if we scale |
| TQ-07 | How to handle the case where GitHub notifies a webhook for a repo that's been disconnected in our system? | Data integrity | Me; default: if repo not in DB, return 200 and log; don't crash |

---

## 18. Appendix

### A. Sequence diagram — repo connection with webhook install

```
Browser        Frontend          API              Prisma/Postgres       GitHub API
  │               │                │                     │                    │
  │ Click "Connect"                │                     │                    │
  ├──────────────▶│                │                     │                    │
  │               │ POST /api/v1/teams/T1/repos {id:123} │                    │
  │               ├───────────────▶│                     │                    │
  │               │                │  auth + authz       │                    │
  │               │                ├────────────────────▶│                    │
  │               │                │◀────────────────────┤                    │
  │               │                │  check repo not     │                    │
  │               │                │  already connected  │                    │
  │               │                ├────────────────────▶│                    │
  │               │                │◀────────────────────┤                    │
  │               │                │                     │ GET /repos/owner/repo
  │               │                ├────────────────────────────────────────▶│
  │               │                │◀────────────────────────────────────────┤
  │               │                │                     │ POST /hooks        │
  │               │                ├────────────────────────────────────────▶│
  │               │                │◀────────────────────────────────────────┤
  │               │                │  INSERT repository   │                    │
  │               │                ├────────────────────▶│                    │
  │               │                │  start backfill job │                    │
  │               │                │  (inline for MVP)   │                    │
  │               │                │                     │ GET /commits?since=… (paginated)
  │               │                ├────────────────────────────────────────▶│
  │               │                │◀────────────────────────────────────────┤
  │               │                │  INSERT commits     │                    │
  │               │                ├────────────────────▶│                    │
  │               │                │◀────────────────────┤                    │
  │               │                │                     │ GET /pulls         │
  │               │                ├────────────────────────────────────────▶│
  │               │                │◀────────────────────────────────────────┤
  │               │                │  INSERT PRs         │                    │
  │               │                ├────────────────────▶│                    │
  │               │                │  201 Created        │                    │
  │               │◀───────────────┤                     │                    │
  │ redirect to dashboard          │                     │                    │
  │◀──────────────┤                │                     │                    │
```

### B. State machine — pull request (mirrors GitHub's states)

```
         ┌─────────┐
  open──▶│  OPEN   │
         └────┬────┘
              │
     ┌────────┴────────┐
     │                 │
  close              merge
     │                 │
     ▼                 ▼
┌─────────┐      ┌─────────┐
│ CLOSED  │      │ MERGED  │
└─────────┘      └─────────┘
```

We capture all three terminal states. A closed PR that's later merged (rare) is treated as MERGED by the webhook handler.

### C. Glossary

- **Authz** — authorization (what you're allowed to do)
- **Authn** — authentication (who you are)
- **HMAC** — hash-based message authentication code; webhook signature mechanism
- **Idempotent** — same operation, same result, any number of applications
- **P0/P1/P2** — priority tiers; see PRD
- **PKCE** — Proof Key for Code Exchange; OAuth security extension (not used here because we're a confidential client)
- **RBAC** — role-based access control
- **RPO** — recovery point objective (max tolerable data loss in time)
- **RTO** — recovery time objective (max tolerable downtime)
- **SLO** — service level objective
- **STRIDE** — threat modeling framework: Spoofing/Tampering/Repudiation/InfoDisclosure/DoS/Elevation

### D. Document conventions

- ADR = Architecture Decision Record
- Code shown in this document is illustrative, not necessarily final
- All ASCII diagrams are source-of-truth; prettier diagrams in Excalidraw/Lucid can be generated later without changing intent
