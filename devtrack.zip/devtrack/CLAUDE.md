# CLAUDE.md — DevTrack

Developer guide for Claude Code. Read this before touching any file.

---

## What this project is

**DevTrack** is a GitHub commit analytics dashboard. Users sign in with GitHub OAuth, connect one repository, and get a clean view of commit activity — daily/weekly bar chart, contributor leaderboard, recent commits. It is a monorepo with a React + Vite frontend (`client/`) and an Express + Prisma backend (`server/`).

---

## Tech stack

| Layer | Tech |
|---|---|
| Frontend | React 18, Vite 5, TailwindCSS 3, TanStack Query v5, Recharts, Lucide React, React Router v6 |
| Backend | Node.js 20, Express 4, Prisma 5 (ORM), PostgreSQL |
| Auth | GitHub OAuth 2.0 — authorization code flow, httpOnly session cookies |
| Security | Helmet, AES-256-GCM token encryption, rate limiting (express-rate-limit) |
| Logging | Winston (JSON), request-ID propagation via middleware |
| Testing | Jest + Supertest (server only), 70 % line coverage threshold |
| CI | GitHub Actions (`.github/workflows/ci.yml`) |

---

## Repo layout

```
devtrack/
├── package.json          # Monorepo root — workspaces: client, server
├── client/               # React + Vite SPA
│   ├── index.html
│   ├── public/           # Static assets (favicon.svg)
│   ├── tailwind.config.js
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── index.css       # Design system (plain CSS + @layer utilities)
│       ├── pages/          # Landing, Dashboard, Demo, Settings, AuthCallback, NotFound
│       ├── components/
│       │   ├── layout/     # Navbar, Layout
│       │   ├── charts/     # CommitChart (Recharts)
│       │   ├── ui/         # StatCard, CommitList, ContributorCard, LoadingSpinner, ErrorState
│       │   ├── RepoSelector.jsx
│       │   ├── DateRangePicker.jsx
│       │   └── utils/time.js
│       ├── context/        # AuthContext, ThemeContext
│       ├── hooks/          # useStats, useRepos
│       └── services/api.js # Axios instance + all API calls
└── server/
    ├── index.js            # Entry — creates app, starts listener
    ├── prisma/
    │   ├── schema.prisma   # User, Session, Repository, Commit models
    │   ├── migrations/
    │   └── seed.js         # Seeds demo data (facebook/react commits)
    └── src/
        ├── app.js          # Express middleware chain + route mounting
        ├── config/env.js   # Zod env validation — exits on invalid config
        ├── controllers/    # auth, repos, stats
        ├── middleware/     # authenticate, requestId, errorHandler, rateLimiter
        ├── routes/         # auth, repos, stats, health
        ├── services/       # auth, github, repos, stats (business logic — no Express deps)
        └── utils/          # crypto (AES-GCM), logger (Winston), response helpers
```

---

## First-time setup

### 1 — Prerequisites
- Node.js ≥ 20
- PostgreSQL running locally (or a connection string to a hosted instance)
- A GitHub OAuth App ([create here](https://github.com/settings/developers))
  - Homepage URL: `http://localhost:5173`
  - Callback URL: `http://localhost:4000/api/v1/auth/github/callback`

### 2 — Environment variables

Copy `server/.env.example` → `server/.env` and fill in every value:

```bash
DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/devtrack
GITHUB_CLIENT_ID=<from GitHub OAuth App>
GITHUB_CLIENT_SECRET=<from GitHub OAuth App>

# Generate session secret (32+ random chars):
# node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
SESSION_SECRET=<random 64-char hex>

# Generate AES-256 key (must be exactly 32 bytes, base64-encoded):
# node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
ENCRYPTION_KEY=<32-byte base64 string>

FRONTEND_URL=http://localhost:5173
PORT=4000
NODE_ENV=development
```

### 3 — Install & migrate

```bash
npm install                        # installs all workspaces
cd server && npx prisma migrate dev --name init
cd server && npm run db:seed       # optional: loads facebook/react demo data
```

### 4 — Run dev servers

```bash
npm run dev          # starts both client (port 5173) and server (port 4000) concurrently
```

Client: http://localhost:5173  
Server: http://localhost:4000  
Prisma Studio: `cd server && npm run db:studio`

---

## Common commands

```bash
npm run dev                          # run client + server concurrently
npm run build                        # Vite production build (client only)
npm run lint                         # ESLint both workspaces
npm run test --workspace=server      # Jest tests
npm run test:coverage --workspace=server  # Jest with coverage report
cd server && npm run db:migrate      # run pending migrations (production)
cd server && npm run db:generate     # regenerate Prisma client after schema changes
cd server && npm run db:seed         # seed demo data
```

---

## API reference

All routes are prefixed `/api/v1`. All responses follow the envelope:
```json
{ "success": true, "data": { ... } }
{ "success": false, "message": "...", "code": "ERR_CODE", "requestId": "req_..." }
```

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/health` | No | DB liveness probe |
| GET | `/auth/github` | No | Start OAuth flow (redirect to GitHub) |
| GET | `/auth/github/callback` | No | GitHub callback — exchanges code, sets cookie |
| GET | `/auth/me` | Cookie | Current user + connected repo |
| POST | `/auth/logout` | Cookie | Clear session |
| GET | `/repos/available` | Cookie | List user's GitHub repos |
| POST | `/repos` | Cookie | Connect a repo (`{ githubRepoId }`) |
| DELETE | `/repos` | Cookie | Disconnect connected repo |
| GET | `/stats/commits?from=&to=` | Cookie | Daily buckets + summary + contributors |
| GET | `/stats/demo` | No | Demo stats (seeded facebook/react) |

**Rate limits:** 100 req / 15 min general, 20 req / 15 min on auth routes.

---

## Database models

```
User         id, githubId, username, email?, avatarUrl?, accessToken (encrypted), timestamps
Session      id, token (unique), userId → User, expiresAt
Repository   id, userId → User, githubRepoId (unique), name, fullName, private, archived
Commit       id, repoId → Repository, sha, message, authorLogin, timestamp, url
             UNIQUE(repoId, sha)
             INDEX(repoId, timestamp DESC)
             INDEX(authorLogin, timestamp DESC)
```

---

## Architecture decisions

| Decision | Rationale |
|---|---|
| Session cookies (httpOnly + Secure + SameSite=Lax) | Simpler than JWT for MVP; no refresh token complexity |
| AES-256-GCM for GitHub token at rest | Tokens are PII-adjacent; must never appear in logs or DB dumps plaintext |
| 5-min in-process cache for commit stats | GitHub API has low rate limits; repeated date-range changes would exhaust quota |
| Services are framework-agnostic | Controllers are thin; services have zero Express imports — makes them unit-testable |
| Monorepo workspaces | Single `npm install`, unified CI, shared scripts without a build tool like Nx/Turborepo |
| Tailwind CSS with plain CSS component classes | Avoids the `@apply` + custom-color stacking variant bug in Tailwind v3 PostCSS (dark:hover:bg-custom won't compile inside @apply) |

---

## Frontend design system

The CSS design system lives entirely in `client/src/index.css` using plain CSS inside `@layer components` and `@layer utilities`. Do **not** use `@apply` with stacked variants on custom colors (e.g. `dark:hover:bg-surface-muted`) — this causes a PostCSS compile error in Tailwind v3. Instead, write plain `.dark .selector:hover` CSS rules.

### Key component classes

| Class | Description |
|---|---|
| `.card` | White/dark-elevated surface, border, rounded-xl, subtle shadow |
| `.btn-primary` | Green filled button |
| `.btn-secondary` | Outlined button, light/dark aware |
| `.btn-ghost` | Transparent hover-only button |
| `.input-base` | Consistent form input with focus ring |
| `.badge`, `.badge-green`, `.badge-gray` | Small pill labels |
| `.section-label` | All-caps 11px section heading |
| `.gradient-text-accent` | Green-to-emerald gradient text |
| `.hero-glow` | Radial green gradient for landing page hero |
| `.dot-grid` | Dot pattern background overlay |

### Custom Tailwind tokens (tailwind.config.js)

```js
colors: {
  accent:  { DEFAULT: '#2da44e', hover: '#2c974b', light: '#d1fae5', muted: 'rgba(45,164,78,0.12)' }
  surface: { DEFAULT: '#0d1117', elevated: '#161b22', card: '#1c2128', muted: '#21262d', border: '#30363d' }
}
shadows: card, card-md, card-lg, glow
animations: fade-in, fade-up, slide-down, bar-grow, pulse-slow
```

---

## Testing

Tests live in `server/tests/`. Run with:
```bash
cd server && npm test
```

- **Unit tests** — `tests/unit/` — cover services and utils in isolation (no DB, no HTTP)
- **Integration tests** — `tests/integration/` — spin up the Express app with Supertest; use a test DB
- Coverage threshold: 70 % lines (enforced by Jest config in `server/package.json`)
- Do not mock the database in integration tests — prior incident where mock/prod divergence masked a broken migration

---

## Deployment notes

1. Set `NODE_ENV=production` — activates `Secure` cookie flag and disables stack traces in error responses
2. Run `npm run db:migrate` before starting the server on a new instance
3. `FRONTEND_URL` must exactly match the origin served by your CDN/reverse proxy
4. The GitHub OAuth callback URL registered in the GitHub app must match `{server_origin}/api/v1/auth/github/callback`
5. Do not expose the server port directly — put it behind nginx/Caddy with TLS termination

---

## Known limitations / P1 backlog

- Account deletion endpoint is stubbed (`alert()` in UI) — backend `DELETE /api/v1/account` not yet implemented
- Session tokens are not rotated on use (planned JWT refresh in P1)
- Only one repo per user (by design for MVP)
- GitHub token is refreshed on next login only — no background refresh
