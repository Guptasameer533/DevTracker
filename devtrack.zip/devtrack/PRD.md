# DevTrack — Product Requirements Document (v2.0)

**Document version:** 2.0 (major rewrite)
**Author:** Sameer Gupta
**Status:** Pre-implementation
**Last updated:** April 2026

---

## 0. Changelog from v1.0

This document is a substantial rewrite responding to review feedback. Key changes:

- **Reframed as a portfolio project** with production-grade engineering execution, not a market-facing product. This removes the contradiction between "real product" and "demo" framings.
- **Evidence section** added, honest about the secondary nature of the research (no primary user interviews were conducted).
- **MVP tightly scoped** — solo-user core only. Teams, real-time webhooks, and backfill moved to Phase 2.
- **Competitive analysis expanded** from one sentence to a full section (§6).
- **UX specification** added as §14 with wireframe-level descriptions for every screen.
- **Edge cases & error states** added as §16, specifying behavior for 15+ failure modes.
- **Analytics, privacy, versioning** sections added.
- **Strategic risks** added to §19 (adoption risk, platform risk, PMF risk).
- **Timeline doubled** from 4 weeks to 8 weeks with explicit assumptions.
- **Success metrics rewritten** from deliverables to outcomes (activation, time-to-demo-value).
- **Open questions expanded** from 4 to 13, with decision owners.

---

## 1. Executive Summary

DevTrack is a **portfolio-grade full-stack engineering demonstration** built around a real, narrow problem: aggregating GitHub contribution activity into a single dashboard. The project exists primarily to showcase full-stack engineering competence to recruiters — not to capture market share from incumbents like LinearB or Swarmia.

The scope is deliberately constrained. The **MVP (v1.0)** is a single-user tool that connects one to three repos and shows one month of commit activity. The full spec described here (v2.0 — teams, webhooks, individual breakdowns) is the **target state** reachable in roughly 8 weeks of part-time work.

Every technical choice in this document is justified against the project's actual purpose: demonstrate engineering depth in a system small enough to understand end-to-end. We pick Postgres over Mongo not because the market demands it, but because an interviewer evaluating the code will see relational modeling done correctly. We pick webhooks over polling not because real-time matters to the user, but because webhook signature verification is a non-trivial thing to have shipped.

**This framing is explicit and owned.** It is not a failed attempt at a real product; it is a successful attempt at a resume artifact.

---

## 2. Problem Statement & Evidence

### 2.1 The hypothesis

Engineering leads of small teams (3–10 developers) lack a consolidated activity view across the 3–10 GitHub repos their team works on. They resort to either manually checking per-repo GitHub Insights, paying for enterprise tools (LinearB, Swarmia, Haystack) that are overkill and expensive for their size, or writing ad-hoc scripts that break.

### 2.2 Honest note on evidence

**No primary user interviews were conducted for this PRD.** Doing so is out of scope for a portfolio project on a compressed timeline. This section draws entirely on secondary sources and should be treated as a *well-founded hypothesis*, not validated demand.

The hypothesis is supported, with caveats, by:

- **GitHub's own product direction.** GitHub shipped "Pulse" and "Insights" features per-repo, which indicates they believe the demand exists; the absence of a cross-repo aggregation in those features indicates an unfilled gap at least in GitHub's view.
- **LinearB, Swarmia, Haystack exist and are venture-funded.** Multiple VC-backed companies solving adjacent versions of this problem is an imperfect but meaningful signal.
- **Public pain-point sources.** Developer Twitter/X threads and r/ExperiencedDevs threads on "how do you track team velocity?" routinely surface "we built our own script" as a common answer. This is not rigorous, but it is consistent.

### 2.3 What we are NOT claiming

- We are not claiming to have talked to real tech leads about this.
- We are not claiming the problem is painful enough to drive paid adoption.
- We are not claiming DevTrack would survive competition with LinearB on features.

These are legitimate open questions (see §22) that a *real* productization would need to answer. For a portfolio project, the above hypothesis is sufficient grounding to build against.

---

## 3. Goals & Success Metrics

### 3.1 Project goals

| # | Goal | Why |
|---|------|-----|
| G1 | Build a full-stack application that demonstrates production-quality engineering end-to-end | Primary purpose: interview signal |
| G2 | Cover ~8 distinct engineering competencies (OAuth, JWT rotation, webhooks, HMAC, SQL modeling, state aggregation, CI/CD, testing) in one coherent codebase | Each is a talking point in an interview loop |
| G3 | Ship a publicly accessible, clickable demo | Interviewers open links, not READMEs |
| G4 | Write a codebase a senior engineer would not be embarrassed to review | Code quality is the thing that gets you hired, not feature count |

### 3.2 Success metrics — outcome based

| Metric | Target | How measured |
|--------|--------|---------------|
| **Time from landing on site to first chart rendered** | < 90 seconds | Manual stopwatch test with 5 friends unfamiliar with the project |
| **"I understood what this does in under a minute" (friend test)** | 4 out of 5 testers | Informal user test with peers |
| **% of code paths covered by tests** | ≥ 70% of auth + stats + webhook code | Jest coverage report |
| **Recruiters who open the demo and click through at least 2 pages** | ≥ 50% of unique visits in 30 days | PostHog funnel |
| **Interview conversations where DevTrack is a concrete discussion topic for ≥ 5 min** | ≥ 3 in 60 days after ship | Self-reported, logged in a notes file |
| **p95 API response time for dashboard endpoint** | < 300 ms | Instrumented in backend, reported to logs |

These are outcomes (did interviewers engage, did the thing feel fast) not outputs (did we ship feature X).

### 3.3 Anti-goals — things we explicitly do NOT optimize for

- **Monthly active users** — not the point of this project
- **Revenue or conversion** — no monetization planned
- **Feature parity with LinearB** — we will always lose that race
- **Mobile responsiveness beyond tablet** — desktop demo is primary consumption context for recruiters

---

## 4. Non-Goals (Explicit)

- No replacement for GitHub itself — we read activity, we don't host code
- No code review features — we track PR metadata, not diffs
- No sprint/kanban/task management
- No CI/CD observability — we don't track builds or deploys
- No support for GitLab, Bitbucket, Gitea in v1 or v2
- No Slack/Discord integrations in v1 or v2
- No AI-generated summaries ("your team shipped 40% more this week!")

---

## 5. Target Users

### 5.1 Framing note

These are **target users we are designing the experience for**, based on observable behavior from secondary sources (§2.2) — not validated personas from field research. They are honest about who would realistically use the tool if it shipped.

### 5.2 Target user A — "Tech lead at a small startup"

- Runs a team of 3–8 engineers
- Manages 3–10 active repositories
- Evaluates tools on cost (< $20/user/month) and setup time (< 30 min)
- Current workflow: checks GitHub Insights per-repo, maintains mental model of who's working on what, has a Notion page with weekly summaries written by hand
- Observable pain point (Twitter/X, r/ExperiencedDevs, Hacker News comments): "I don't have time to write weekly team updates. I wish GitHub just summarized this."
- Would use DevTrack for: weekly 1:1 prep, board/investor updates, spotting who's getting buried

### 5.3 Target user B — "Solo engineer / consultant"

- Works across 3–6 client repos
- Wants a single view of what they personally shipped this month
- Current workflow: opens each repo, looks at their own commits, copies into a weekly report
- Observable pain point (Indie Hackers forum, freelance subreddits): "I spend 30 min/week writing up what I did, a bot could do this for me"
- Would use DevTrack for: client status reports, invoicing backup, portfolio maintenance

### 5.4 Target user C — "Portfolio evaluator" (the honest primary user)

- Recruiter, hiring manager, or senior engineer reviewing Sameer's portfolio
- Lands on the demo via resume or LinkedIn link
- Has ~2 minutes of attention budget
- Expects: clear login, obvious value within 30 seconds, no broken states
- This user's needs drive many UX decisions (onboarding speed, demo mode, no empty states)

---

## 6. Competitive Analysis

### 6.1 Feature matrix

| | **GitHub Insights (native)** | **LinearB** | **Swarmia** | **Haystack** | **DevTrack (v2.0)** |
|---|---|---|---|---|---|
| Price | Free (with GitHub) | $20+/dev/mo | $20+/dev/mo | $18+/dev/mo | Free (self-host) |
| Cross-repo aggregation | ❌ (per-repo only) | ✅ | ✅ | ✅ | ✅ |
| Per-developer breakdown | ❌ | ✅ | ✅ | ✅ | ✅ |
| PR cycle time metrics | ❌ | ✅ | ✅ | ✅ | ❌ (out of scope) |
| DORA metrics | ❌ | ✅ | ✅ | ✅ | ❌ (out of scope) |
| Slack integration | ❌ | ✅ | ✅ | ✅ | ❌ |
| Jira integration | ❌ | ✅ | ✅ | ✅ | ❌ |
| Self-hostable | N/A | ❌ | ❌ | ❌ | ✅ |
| Setup time (estimated) | 0 min (already there) | 1–2 hours | 1–2 hours | 1–2 hours | 10 min |
| Time to first value | Instant | Days | Days | Days | < 2 min |

### 6.2 Honest competitive positioning

**DevTrack cannot win on features.** The market leaders have 2–5 years of head start, engineering teams of 20+, and shipped DORA metrics, cycle time analysis, Slack integrations, and Jira connectors that DevTrack will never match.

**DevTrack's only defensible positioning is:**

1. **Free and self-hostable** — for teams that can't or won't pay $20/dev/month
2. **Opinionated minimal surface area** — doesn't try to do DORA, cycle time, bottleneck analysis
3. **Fast setup** — GitHub OAuth → first chart in under 2 minutes

This is a narrow positioning, and it is unlikely to be commercially viable without significant additional features. **This is fine** — the project is not attempting commercial viability.

### 6.3 Why not just use GitHub Insights?

The one-line answer: GitHub Insights does not aggregate across repos. Every other feature DevTrack has could, in principle, be built into GitHub by GitHub itself; this is the **platform risk** called out in §19.

---

## 7. User Stories

Prioritized. **P0** is MVP. **P1** is v2.0. **P2** is post-v2.0.

### P0 — MVP (single user, single repo, polling)

- **US-01 (P0):** As a user, I want to sign in with my GitHub account so I don't create a new password
- **US-02 (P0):** As a user, I want to connect one of my GitHub repos so I can see its activity
- **US-03 (P0):** As a user, I want to see a daily commit chart for the last 30 days so I can understand my cadence
- **US-04 (P0):** As a user, I want to see total commit count so I have a headline number
- **US-05 (P0):** As a user, I want my session to persist across browser restarts so I don't re-login daily

### P1 — v2.0 target state (teams, multi-repo, webhooks)

- **US-06 (P1):** As a user, I want to create a team and invite others so multiple people share a dashboard
- **US-07 (P1):** As a team member, I want to see aggregate team metrics across all connected repos
- **US-08 (P1):** As a team member, I want to see per-developer breakdown so I can spot who's active and who's blocked
- **US-09 (P1):** As a team member, I want to see activity appear within 30 seconds of a commit (webhooks, not polling)
- **US-10 (P1):** As a team owner, I want to disconnect a repo and have its webhook cleanly removed from GitHub

### P2 — Future / out of scope

- US-11 through US-20 moved to §21 Out of Scope

---

## 8. MVP Scoping (the section the v1.0 PRD was missing)

### 8.1 The MVP in one sentence

**A single logged-in user connects one GitHub repo and sees a chart of their last 30 days of commits.**

That is the whole MVP. Everything else is Phase 2.

### 8.2 What's explicitly OUT of the MVP

- Teams. Single user only.
- Webhooks. Data is fetched on page load by calling GitHub API directly (with caching).
- Individual vs team views. Only one view.
- PRs and issues. Commits only.
- Refresh token rotation. Session cookie only.
- Per-developer breakdown. Only the logged-in user's own data.
- Repo disconnection UI. Disconnect via database or API call, not UI.
- Tests. Minimal smoke tests, not full coverage.

### 8.3 Why this MVP

- **Ships in 5–7 days of real work.** Provable.
- **Fully demonstrates the hardest parts:** OAuth flow, GitHub API integration, chart rendering, a deployed full-stack app.
- **Has a clear, clickable demo** that works end-to-end even if every Phase 2 feature is broken.
- **Recoverable** — if Phase 2 slips or breaks, the MVP is still a shippable portfolio artifact.

### 8.4 Kill criteria for Phase 2

After MVP ships, we check:

- Is the MVP working reliably in production for ≥ 7 days?
- Did at least 5 people (friends, classmates, Discord) actually log in and use it?
- Are there bugs in the MVP that should be fixed before adding complexity?

If any answer is "no," we do not start Phase 2 until all three are "yes."

---

## 9. Functional Requirements

Only P0 requirements are listed in full. P1 requirements are referenced but deferred to v2.0 delivery.

### 9.1 Authentication (P0)

| ID | Requirement |
|----|-------------|
| FR-AUTH-1 | GitHub OAuth 2.0 with scopes `read:user`, `user:email`, `repo` |
| FR-AUTH-2 | Session is a signed httpOnly cookie with 7-day expiry (MVP simplification — JWT refresh added in P1) |
| FR-AUTH-3 | Logout clears the cookie and invalidates the session server-side |
| FR-AUTH-4 | Protected routes reject unauthenticated requests with 401 |

### 9.2 Repository connection (P0)

| ID | Requirement |
|----|-------------|
| FR-REPO-1 | User sees list of their GitHub repos fetched from `/user/repos` |
| FR-REPO-2 | Connecting a repo stores the repo record (no webhook in MVP) |
| FR-REPO-3 | MVP supports only 1 connected repo per user — surfaced as limitation, not a bug |

### 9.3 Stats (P0)

| ID | Requirement |
|----|-------------|
| FR-STATS-1 | On dashboard load, fetch last 30 days of commits from GitHub API for the connected repo |
| FR-STATS-2 | Cache results in Postgres for 5 minutes to avoid repeated API calls |
| FR-STATS-3 | Return a daily bucket: `[{date, commitCount}]` |
| FR-STATS-4 | If the user has no connected repo, return empty state (not error) |

### 9.4 P1 requirements (referenced, not specified in detail here)

- Team management (create, invite, remove)
- Multi-repo connection
- Webhook installation + HMAC signature verification
- Event deduplication on `X-GitHub-Delivery`
- Per-developer stats breakdown
- Individual developer drilldown
- JWT access + refresh token rotation

---

## 10. Non-Functional Requirements

| Category | Requirement | Rationale |
|----------|-------------|-----------|
| **Performance** | API endpoints respond < 300ms p95 under 10 concurrent users | 300ms is the widely-cited threshold for "feels instant" |
| **Performance** | Dashboard first-paint < 2s on 4G | Google Core Web Vitals LCP "good" threshold |
| **Security** | All secrets in env vars, never in repo | Table stakes |
| **Security** | HTTPS enforced in production | Browser security |
| **Security** | CORS restricted to known frontend origin | Prevents arbitrary site from using the API |
| **Security** | Rate limits: **100 req/15min on general endpoints, 20 req/15min on auth** | Based on: normal dashboard user makes ~10 req/page, 10 page loads in 15 min = 100. Auth endpoints tighter because brute-forceable. |
| **Security** | HMAC signature verification on all webhooks (P1) | GitHub's own recommended practice |
| **Observability** | Structured JSON logs in production via Winston | Parseable by any log aggregator |
| **Observability** | Every API error logged with request context (path, method, userId, requestId) | Debugging production |
| **Observability** | Request IDs propagated through logs via middleware | Trace across log lines |
| **Compatibility** | Latest 2 versions of Chrome, Firefox, Safari, Edge | 95%+ of real users |
| **Compatibility** | Desktop-first; functional but not polished on tablet; mobile is P2 | Primary user is desktop (recruiter) |
| **Compatibility** | Dev setup works on macOS and Windows | Stated requirement |
| **Testing (P0)** | Smoke test: can log in, connect repo, see chart | Ship-gate for MVP |
| **Testing (P1)** | 70%+ coverage on auth, stats, webhook code | Ship-gate for v2.0 |

---

## 11. Technical Architecture

### 11.1 Architecture diagram

```
┌─────────────┐      ┌──────────────────┐      ┌────────────────┐
│             │─────▶│  React Frontend  │─────▶│  Express API   │
│   Browser   │◀─────│  (Vercel)        │◀─────│  (Render)      │
│             │      │                  │      │                │
└─────────────┘      └──────────────────┘      └───────┬────────┘
                                                       │
                                                       ▼
                                              ┌────────────────┐
                                              │   PostgreSQL   │
                                              │   (Render)     │
                                              └────────────────┘

                     (P1 only: webhooks)
                                                       │
┌─────────────┐                                        │
│   GitHub    │────────────── webhook POST ────────────┘
└─────────────┘
```

### 11.2 Stack & rationale

| Layer | Choice | Why this over alternatives |
|-------|--------|----------------------------|
| Frontend framework | React 18 + Vite | Vite over CRA (faster dev, less bundler config); React over Vue/Svelte because skill signal is stronger |
| Routing | React Router v6 | De-facto; no SSR need that would justify Next.js |
| Data fetching | TanStack Query v5 | Built-in caching, retries, revalidation. Avoids rolling our own |
| Charts | Recharts | Declarative, React-native, composable. D3 is overkill. |
| Styling | Tailwind CSS | Fast, no CSS file sprawl, recruiters recognize it |
| Backend runtime | Node.js 20 LTS | Matches frontend lang; skill signal |
| Backend framework | Express | Mature, minimal lock-in. Fastify slightly faster but obscures skill signal |
| ORM | Prisma | Type-safe queries, migrations out of the box, good DX |
| DB | PostgreSQL | Relational data fits; JSON columns for flexibility; interviewer-expected |
| Auth | GitHub OAuth + (P0 cookie / P1 JWT) | OAuth because we need GH tokens anyway |
| Validation | Zod | Runtime + inference. Plays with TS later |
| Testing | Jest + Supertest | Standard for Node APIs |
| CI/CD | GitHub Actions | Native; free on public repos |
| Frontend host | Vercel | Best DX for React; free tier handles a demo |
| Backend host | Render | Free tier with Postgres bundled; fewer moving parts than AWS |

### 11.3 API versioning

All API routes are prefixed `/api/v1/...`. When breaking changes ship, a v2 path is added alongside v1; v1 supported for a deprecation window. This matters even for a portfolio project because the versioned URL is visible in every network request and shows an interviewer that you think about API evolution.

---

## 12. Data Model

### 12.1 ERD

```
User ───(1)───(n)─── Session
 │
 ├──(1)───(n)─── Repository (P0: 1 per user, P1: via Team)
 │                    │
 │                    ├──(1)───(n)─── Commit
 │                    ├──(1)───(n)─── PullRequest  (P1)
 │                    └──(1)───(n)─── Issue         (P1)
 │
 └──(P1)── owns ── Team ──(n)── TeamMember ──── User
                    │
                    └──(1)───(n)─── Repository
```

### 12.2 Tables (P0)

- **users** — `id, githubId (u), username (u), email, avatarUrl, accessToken, createdAt, updatedAt`
- **sessions** — `id, token (u), userId, expiresAt, createdAt` (P0 only; replaced by `refresh_tokens` in P1)
- **repositories** — `id, userId, githubRepoId (u), name, fullName, private, createdAt`
- **commits** — `id, repoId, sha, message, authorLogin, timestamp, url` — unique on (repoId, sha)

### 12.3 P1 additions

- `teams`, `team_members`, `refresh_tokens`, `pull_requests`, `issues`, `webhook_events`
- `repositories.teamId` replaces `repositories.userId`; migration required
- `repositories.webhookId` column added

### 12.4 Indexes

| Table | Index | Reason |
|-------|-------|--------|
| `commits` | `(repoId, timestamp DESC)` | Daily aggregation queries — primary hot path |
| `commits` | `(authorLogin, timestamp DESC)` | Per-developer views (P1) |
| `sessions` | `(token)` unique | Session lookup on every request |
| `repositories` | `(githubRepoId)` unique | Prevents same repo connected by two users |

---

## 13. API Specification

P0 only. Full P1 spec deferred. All routes prefixed `/api/v1`.

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| GET | `/auth/github` | Redirect to GitHub OAuth | No |
| GET | `/auth/github/callback` | Callback; sets session cookie; redirects to frontend | No |
| GET | `/auth/me` | Returns current user | Cookie |
| POST | `/auth/logout` | Clears session cookie | Cookie |
| GET | `/repos/available` | Lists repos user can connect | Cookie |
| POST | `/repos` | Connects a repo: `{ githubRepoId }` | Cookie |
| GET | `/stats/commits?from&to` | Returns `[{date, count}]` for connected repo | Cookie |

Error response shape, consistent across all endpoints:

```json
{ "success": false, "message": "Human readable", "code": "ERR_CODE", "requestId": "uuid" }
```

---

## 14. UX Specification (new section — was missing from v1.0)

### 14.1 Information architecture

```
/                    → Landing page (logged-out) / redirects to /dashboard (logged-in)
/auth/callback       → OAuth callback handler
/dashboard           → Main dashboard (chart + stats)
/connect             → Repo picker
/settings            → Account + disconnect
/demo                → Live demo mode with seeded data (no login)
```

### 14.2 Wireframe descriptions

#### Landing page (logged-out)

```
┌─────────────────────────────────────────────────────────┐
│  [DevTrack logo]                        [Sign in]       │
├─────────────────────────────────────────────────────────┤
│                                                         │
│   Headline: See your GitHub activity in one chart       │
│   Subhead:  Connect a repo in under 30 seconds.         │
│                                                         │
│        [ Sign in with GitHub → ]                        │
│        [ Or see a live demo ]   ← seeded demo mode      │
│                                                         │
│   [ animated preview of the chart ]                     │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

Content: Single H1, one subhead line, two CTAs (primary: sign in, secondary: demo). No feature list, no testimonials, no pricing. The goal is to get visitors to either click "sign in" or "see demo" within 10 seconds.

#### Dashboard (logged-in, has connected repo)

```
┌─────────────────────────────────────────────────────────┐
│  DevTrack  |  Dashboard  Settings            [avatar]   │
├─────────────────────────────────────────────────────────┤
│  Repo: owner/repo-name   [Change repo]                  │
│                                                         │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐                 │
│  │ Commits  │ │  Last    │ │  Top     │                 │
│  │   42     │ │  commit  │ │   day    │                 │
│  │  30d     │ │  2h ago  │ │  Tue (8) │                 │
│  └──────────┘ └──────────┘ └──────────┘                 │
│                                                         │
│  ┌───────────────────────────────────────────────────┐  │
│  │    Commits over time                              │  │
│  │                                                   │  │
│  │    [ Recharts bar chart — daily buckets ]         │  │
│  │                                                   │  │
│  └───────────────────────────────────────────────────┘  │
│                                                         │
│  Recent commits:                                        │
│  • abc123  "fix: null check" — 2h ago                   │
│  • def456  "feat: add x"     — 5h ago                   │
└─────────────────────────────────────────────────────────┘
```

Hierarchy: repo selector at top, three at-a-glance stats cards, one hero chart, recent commits list below the fold. Single column on desktop; do not introduce multi-column until we know we have more data types to show.

#### Dashboard (logged-in, no repo connected — onboarding state)

```
┌─────────────────────────────────────────────────────────┐
│  Welcome, {username}                                    │
│                                                         │
│   You're in. One more step:                             │
│                                                         │
│   ┌──────────────────────────────────────────────┐      │
│   │   Pick a repo to connect:                    │      │
│   │   ○ user/project-a       (updated 2d ago)    │      │
│   │   ○ user/project-b       (updated 1w ago)    │      │
│   │   ○ user/project-c       (updated 2w ago)    │      │
│   │                                              │      │
│   │   [Connect →]                                │      │
│   └──────────────────────────────────────────────┘      │
│                                                         │
│   Or [ skip and see a sample dashboard ] first.         │
└─────────────────────────────────────────────────────────┘
```

Critical: the onboarding state does NOT show an empty dashboard. It shows the repo picker directly, pre-populated with the user's recent repos, sorted by most-recently-updated. This addresses PM feedback #8 (onboarding dead-end).

#### Demo mode (`/demo`)

Same layout as the dashboard, populated with seeded data from a famous public repo (e.g., `facebook/react` or `vercel/next.js`). Clearly labeled "Demo" in a banner. No login required. This addresses PM feedback #4 (activation) by giving anonymous visitors (including recruiters) a clickable value preview in zero clicks.

### 14.3 Empty states

| State | Copy | Action |
|-------|------|--------|
| No repo connected | "Pick a repo to get started" | Repo picker inline |
| Repo connected but no commits in window | "No commits in the last 30 days on this repo" | Suggest extending date range |
| API error loading stats | "Couldn't reach GitHub. [Retry]" | Retry button |
| GitHub token expired | "Your GitHub session expired. [Sign in again]" | Re-auth CTA |

### 14.4 Visual design

- Dark theme default, light theme as toggle (portfolio aesthetic; recruiters open demos on both)
- Color palette: neutral grays for chrome; single accent color (GitHub-ish green) for primary actions and chart fill
- Typography: Inter or system font stack; no custom webfont (loading cost)
- No illustrations or stock imagery; icon set limited to Lucide

---

## 15. User Flows

### 15.1 First-time sign-in (P0)

1. User lands on `/`, sees headline and two CTAs
2. User clicks "Sign in with GitHub"
3. Browser redirects to `github.com/login/oauth/authorize?...`
4. User approves scope on GitHub's consent screen
5. GitHub redirects to `/api/v1/auth/github/callback?code=...`
6. Backend exchanges code for GitHub access token, upserts user row, creates session, sets httpOnly session cookie
7. Backend redirects to `/dashboard`
8. Frontend: `/dashboard` loads → calls `/api/v1/auth/me` → no `connectedRepoId` → renders onboarding state (§14.2)
9. User picks a repo from the list → frontend POSTs `/api/v1/repos` with `{ githubRepoId }`
10. Frontend refetches `/api/v1/stats/commits?from&to` → renders chart
11. **Time-to-chart target: 90 seconds from step 1**

### 15.2 Returning user (P0)

1. User opens `/` (any page)
2. Session cookie present → backend validates → user is authenticated
3. Root redirects to `/dashboard`
4. Dashboard fetches stats from cache (if < 5 min old) or GitHub API (if stale)
5. Chart renders in < 2 seconds

### 15.3 Demo mode (P0)

1. Anonymous visitor clicks "See live demo" on landing
2. Frontend navigates to `/demo` — no auth required
3. Backend serves pre-seeded data from fixture repo (e.g., `facebook/react` snapshot)
4. Banner: "Live demo with sample data from facebook/react"
5. Two CTAs at bottom: "Sign in to connect your own repo" and "Back to home"

### 15.4 Webhook event ingestion (P1)

1. Developer pushes a commit to a connected repo
2. GitHub fires `POST /api/v1/webhooks/github` with `X-Hub-Signature-256`
3. Backend verifies HMAC using `WEBHOOK_SECRET` → rejects with 401 if invalid
4. Backend checks `X-GitHub-Delivery` against `webhook_events.githubDeliveryId` → skips if duplicate
5. Backend parses event → writes commit/PR/issue rows
6. Backend writes `webhook_events` row with `processed = true`
7. Frontend, on dashboard page, polls `/stats` every 15s → picks up new commit (SSE/WebSocket deferred to P2)

---

## 16. Edge Cases & Error States (new section — was missing from v1.0)

Specifying these is the difference between a PRD and a wishlist.

| # | Scenario | Expected behavior |
|---|----------|-------------------|
| E-01 | User revokes OAuth access in GitHub settings | Next API call returns 401 → frontend detects → clears session → redirects to `/` with banner "Your GitHub access was revoked. Please sign in again." |
| E-02 | User's GitHub token expires (can happen with GH App tokens) | Same as E-01 |
| E-03 | User deletes their GitHub account | Next token refresh fails → session invalidated → user record soft-deleted (not hard-delete for audit) |
| E-04 | Connected repo is deleted or made private after connection | On next stats fetch, GitHub API returns 404 → backend marks repo as `archived = true` → frontend shows "This repo is no longer accessible. [Disconnect]" |
| E-05 | Webhook secret rotated mid-flight | Existing webhooks start failing HMAC verification → backend logs and ignores → user must reconnect repos (documented, not silent) |
| E-06 | 5 consecutive webhook deliveries fail HMAC (P1) | Alert fired to logs (not a silent issue); no automatic action — may indicate attack |
| E-07 | GitHub API rate limit hit (5000 req/hr for user tokens) | Backend returns 503 with `Retry-After` header; frontend shows "GitHub rate limit reached. Try again in N minutes." |
| E-08 | Backfill partially completes (e.g., 200 commits written, then API error on page 3) | Commits written are kept (idempotent via unique constraint); job status marked as `partial`; retry attempts the remaining pages |
| E-09 | User tries to connect a repo they no longer have access to | `/repos` POST returns 403 with "No longer have admin access to this repo" |
| E-10 | Two users try to connect the same repo | Second user gets 409 Conflict with "Repo already connected by another user" (v1.0 single-user; P1 single-team ownership) |
| E-11 | Webhook endpoint receives malformed payload | Returns 400, logs to error tracker, does not crash |
| E-12 | Webhook replay attack (same delivery ID sent 10x) | Dedup on `githubDeliveryId` — 1 write, 9 silent ignores |
| E-13 | User session expired but cookie still present | Backend returns 401 → frontend clears cookie and redirects to `/` |
| E-14 | Database connection lost | Backend returns 503; health check reflects status; requests return "Service temporarily unavailable" |
| E-15 | User connects a repo with zero commits | Dashboard shows empty state with "This repo has no commits yet" instead of blank chart |
| E-16 | User connects a repo with 10,000+ commits | Only last 30 days ingested in MVP; banner "Showing last 30 days" |

---

## 17. Analytics & Instrumentation (new section)

### 17.1 Stack

- **PostHog** (free tier) — product analytics
- Backend structured logs → stdout → captured by Render's log aggregator
- No custom dashboards in v1; PostHog UI is sufficient

### 17.2 Events tracked

| Event | Properties | Why |
|-------|------------|-----|
| `landing_viewed` | `referrer` | Top-of-funnel |
| `github_login_clicked` | — | CTA click-through |
| `github_oauth_completed` | `isNewUser` | Auth funnel step 2 |
| `repo_connected` | `isFirstRepo` | Primary activation event |
| `dashboard_chart_rendered` | `commitsInWindow` | Feature engagement |
| `demo_viewed` | — | Does anonymous demo work? |
| `error_shown` | `errorCode, page` | Quality signal |

### 17.3 Funnels to watch

- **Activation:** `landing_viewed` → `github_login_clicked` → `github_oauth_completed` → `repo_connected` → `dashboard_chart_rendered`. Target: 40%+ complete the full funnel.
- **Demo engagement:** `demo_viewed` → `github_login_clicked`. Target: 20%+.

### 17.4 What we do NOT track

- No PII in event properties beyond `userId`
- No commit content or message text sent to analytics
- No IP-level geolocation (PostHog default off)
- Users can opt out via DNT header (respected)

---

## 18. Privacy & Data Handling (new section)

### 18.1 Data collected & retention

| Data | Retention | Justification |
|------|-----------|---------------|
| GitHub access tokens | Indefinite, encrypted at rest | Required for API calls; deleted on account deletion |
| Email address | Indefinite | For future email features; never used in v1 |
| Commit metadata (sha, message, timestamp) | Indefinite while repo is connected; 30 days after disconnection, then hard-deleted | Enables historical analytics |
| PostHog event data | 6 months | PostHog free-tier default |

### 18.2 User rights

- **Delete account:** `DELETE /api/v1/account` → removes user row + cascades to sessions, repos, commits. Takes effect within 24 hours.
- **Export data:** `GET /api/v1/account/export` → returns JSON of user's data. Deferred to P2.
- **Revoke GitHub access:** direct user to `github.com/settings/applications`; our app detects revocation on next API call (E-01).

### 18.3 Security

- Tokens encrypted at rest using AES-256-GCM with key from env var `ENCRYPTION_KEY`
- Database connection over TLS
- No third-party SDKs with tracking beyond PostHog
- No data sold or shared

### 18.4 Privacy policy

A minimal privacy policy page at `/privacy` will be published before public launch. Content: what data is collected, how it's used, how to delete. Not a legal document — this is a portfolio project, not a business — but sufficient for good-faith operation.

---

## 19. Risks

### 19.1 Operational risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| GitHub API rate limits during backfill | Medium | Medium | Chunked backfill; respect `X-RateLimit-Remaining`; cap at 30 days |
| Webhook secret leak | Low | High | Env vars only; HMAC on every request; rotation documented |
| Render free-tier cold start on demo click | High | Medium | Accept ~30s cold start for now; add a banner "First load is slow — free tier wakeup" |
| Vercel/Render free-tier quota hit | Low | Medium | Monitor usage; upgrade if needed (low monthly cost) |
| Database corruption or loss | Low | High | Daily auto-backup on Render; tested restore procedure before launch |
| Refresh token theft (P1) | Low | High | Rotate on every use, hashed in DB, short TTL |

### 19.2 Strategic risks (new — was missing from v1.0)

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| **Users won't grant `repo` scope** (this is the #1 adoption risk for any tool in this space) | High | High | Document scope need; offer `public_repo`-only mode as fallback in P2; make demo mode available to avoid requiring auth at all |
| **GitHub ships native cross-repo analytics** | Medium (2–3 year horizon) | Fatal for a product; neutral for a portfolio project | Accept; the portfolio value is orthogonal to GitHub's roadmap |
| **Problem isn't painful enough to drive adoption** | High | Fatal for a product; neutral for portfolio | Accept; we are not trying to drive adoption |
| **LinearB / Swarmia ships a free tier** | Medium | High if productizing | Monitor; adjust positioning to self-hosted if this happens |
| **Portfolio project becomes dated** (React class components aesthetic, deprecated deps) | Medium | Medium | Keep deps updated quarterly even post-ship |

### 19.3 Accepted risks (explicit non-mitigations)

- We accept that free-tier hosting may have occasional cold starts during demos
- We accept that the project will not compete with LinearB on features
- We accept that without real user research, some UX decisions will be wrong and discoverable only post-ship

---

## 20. Implementation Phases

Timeline assumes **~12 hours/week** of focused work (realistic for a student balancing college and an internship).

### Phase 0 — Foundations (3 days)
- Monorepo scaffold; eslint; prettier; gitignore; README
- Prisma schema for P0 tables; migration
- Express server boilerplate + middleware (helmet, cors, morgan, rate limit)
- Env validation with Zod

### Phase 1 — MVP (Week 1–2)
- GitHub OAuth flow with session cookie auth
- Connect-one-repo UX + API
- Single-repo stats endpoint (daily commit buckets from GitHub API with Postgres cache)
- React dashboard with one Recharts chart
- Landing page + demo mode (seeded fixture)
- Vercel + Render deploy
- Smoke tests
- **Ship gate: deployed, clickable, shareable URL**

### Phase 2 — Teams (Week 3–4)
- `teams`, `team_members` tables; migration from `repositories.userId` → `repositories.teamId`
- Team CRUD + member invite endpoints
- Team-scoped stats endpoints
- Dashboard team switcher UI

### Phase 3 — Webhooks (Week 5–6)
- Webhook install on repo connect; delete on disconnect
- HMAC verification middleware
- Dedup via `webhook_events`
- Event handlers: push, pull_request, issues
- Per-developer stats aggregation

### Phase 4 — Auth hardening (Week 7)
- Replace session cookie with JWT access + refresh token rotation
- Migration path for existing users
- Individual developer drilldown view

### Phase 5 — Testing + CI/CD polish (Week 8)
- Jest + Supertest coverage ≥ 70% on auth/stats/webhook
- GitHub Actions: lint → test → deploy
- README polish
- Analytics instrumentation wired

**Total: ~8 weeks at 12 hours/week.** Previous v1.0 estimate of 4 weeks was unrealistic and is explicitly revised here.

---

## 21. Out of Scope

### v1.0 out of scope (everything in §8.2)
### v2.0 out of scope

- GitLab, Bitbucket, Gitea support
- Slack, Discord, Teams notifications
- Email digest (daily/weekly summaries)
- DORA metrics (deployment frequency, lead time, MTTR, change failure rate)
- Cycle time, PR review time analytics
- Custom date range beyond last 90 days
- Bulk repo connection (connect all repos at once)
- Organization / workspace hierarchy (org → team → user)
- Jira / Linear integration
- Mobile-optimized UI
- WebSocket / SSE for real-time updates (polling is fine for v2.0)
- AI-generated summaries
- Custom alert thresholds ("ping me when PRs-open > 10")

---

## 22. Open Questions

Expanded from 4 in v1.0 to 13. Each has a proposed default decision and an owner (all "me" in this case, but in a team context this would be a named PM/engineer).

| # | Question | Proposed default | Blocks implementation? |
|---|----------|------------------|-----------------------|
| OQ-01 | Should individual stats be visible to all team members or just the individual + owners? | Visible to all (transparency default) | No, UX layer |
| OQ-02 | What happens to historical data when a repo is disconnected? | Soft-delete for 30 days, then hard-delete | No, background job |
| OQ-03 | Should external contributors (non-DevTrack users) appear in breakdowns? | Yes, by GitHub login only | No |
| OQ-04 | Timezone for date buckets — user local or UTC? | UTC on backend, converted on frontend | No |
| OQ-05 | Should demo mode use real data (seeded) or obviously-fake data? | Real data from a well-known public repo, clearly labeled as demo | No |
| OQ-06 | Should OAuth scopes be upgraded lazily (e.g., ask for `admin:repo_hook` only when connecting a private repo)? | Yes — ask for minimum scopes at login, step up later | **Maybe** — changes OAuth flow |
| OQ-07 | Do we verify GitHub email vs DevTrack account email? | No, trust GitHub as source of truth | No |
| OQ-08 | For P1, can a user connect a repo to multiple teams? | No (prevents double-counting metrics) | **Yes** — schema constraint |
| OQ-09 | Should we expose an API key for users to build their own integrations? | No, not in v2.0 scope | No |
| OQ-10 | How do we handle squash-merge commits (one PR = many commits into main)? | Count each commit individually; accept this inflates commit count vs PR count | **Yes** — affects stats accuracy |
| OQ-11 | Should force-pushes (that rewrite history) update commit data? | No — keep original; mark as "rewritten" if detected | No, can defer |
| OQ-12 | When user deletes their account, what happens to teams they own? | Transfer to oldest team member; if none, soft-delete team | **Yes** — affects data model |
| OQ-13 | Should webhook endpoint verify `X-GitHub-Event` header type matches expected events, or accept all and filter? | Accept all, filter — easier to extend | No |

---

## 23. Appendix

### A. GitHub OAuth scopes

| Scope | Reason | P0 or P1 |
|-------|--------|---------|
| `read:user` | Fetch user profile on login | P0 |
| `user:email` | Primary email | P0 |
| `repo` | Read commits on private repos | P0 |
| `admin:repo_hook` | Install webhooks | P1 |

### B. Environment variables

| Var | Purpose | Required in |
|-----|---------|-------------|
| `DATABASE_URL` | Postgres connection | P0 |
| `GITHUB_CLIENT_ID` | OAuth App | P0 |
| `GITHUB_CLIENT_SECRET` | OAuth App | P0 |
| `SESSION_SECRET` | Sign session cookies | P0 |
| `JWT_ACCESS_SECRET` | Sign access tokens | P1 |
| `JWT_REFRESH_SECRET` | Sign refresh tokens | P1 |
| `WEBHOOK_SECRET` | HMAC webhook verification | P1 |
| `ENCRYPTION_KEY` | Encrypt GitHub tokens at rest | P0 |
| `FRONTEND_URL` | CORS + redirect | P0 |
| `POSTHOG_API_KEY` | Analytics | P0 |

### C. Glossary

- **Backfill** — one-time API-driven import of historical activity on repo connection
- **P0 / P1 / P2** — priority tiers; P0 = MVP, P1 = v2.0 target, P2 = future
- **HMAC** — hash-based message authentication code; used for webhook signature verification
- **Idempotent** — operation can be applied multiple times without changing the result beyond the first application

### D. Versioning policy

- Document version in `## 0. Changelog` at top
- Major rewrites bump major version (v1 → v2)
- Clarifications bump minor version (v2.0 → v2.1)
- All changes logged in changelog section
